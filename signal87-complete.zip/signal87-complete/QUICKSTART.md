# Signal87 AI Platform - Quick Start

Get your Signal87 AI Platform with ARIA up and running in 15 minutes.

## Prerequisites

- Base44 account ([sign up](https://base44.dev))
- Vercel account ([sign up](https://vercel.com))
- Node.js 18+ installed
- Git installed

---

## Deploy Backend (5 minutes)

```bash
# 1. Install Base44 CLI
npm install -g @base44/cli
base44 login

# 2. Navigate to project
cd /home/user/signal87-complete

# 3. Initialize Base44
base44 init
# Select your project or create new: signal87-ai

# 4. Deploy entities (one command)
for file in entities/*.json; do base44 entities deploy "$file"; done

# 5. Deploy functions
base44 functions deploy functions/aria-core.js
base44 functions deploy functions/aria-chat.js --route /api/aria/chat
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch
base44 functions deploy functions/aria-research.js --route /api/aria/research
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing
base44 functions deploy functions/aria-upload.js --route /api/aria/upload
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities

# 6. Test backend
curl https://[your-project].base44.run/api/aria/capabilities
```

**✅ Backend deployed!** Note your API endpoint: `https://[your-project].base44.run`

---

## Deploy Frontend (5 minutes)

### Option 1: Vercel CLI (Fastest)

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Deploy
cd /home/user/signal87-complete
vercel

# 3. Add environment variable when prompted:
# VITE_API_BASE_URL=https://[your-project].base44.run

# 4. Deploy to production
vercel --prod
```

### Option 2: Vercel Dashboard

```bash
# 1. Push to GitHub
git init
git add .
git commit -m "Signal87 AI Platform"
git remote add origin https://github.com/[your-username]/signal87-ai.git
git push -u origin main

# 2. Go to vercel.com/new
# 3. Import your repository
# 4. Add environment variable:
#    VITE_API_BASE_URL=https://[your-project].base44.run
# 5. Deploy
```

**✅ Frontend deployed!** Visit your app: `https://signal87-ai.vercel.app`

---

## Verify Deployment (5 minutes)

### 1. Test Backend

```bash
# Should return JSON with ARIA capabilities
curl https://[your-project].base44.run/api/aria/capabilities
```

### 2. Test Frontend

1. Visit `https://signal87-ai.vercel.app`
2. You should see the black-themed landing page
3. Click "Get Started"
4. You should see the dashboard

### 3. Test ARIA

1. Click the ARIA button (bottom-right, purple gradient)
2. Type: "What can you do?"
3. ARIA should respond with its capabilities

### 4. Test Upload (Optional)

1. Go to Documents tab
2. Click Upload button
3. Upload a PDF document
4. Verify it appears in the document grid

---

## Configure CORS (1 minute)

Allow your frontend to access the backend:

```bash
base44 cors add https://signal87-ai.vercel.app
base44 cors add https://[your-custom-domain].com  # if using custom domain
```

---

## Troubleshooting

### Backend Issues

**Problem**: Functions not deploying
```bash
# Check status
base44 status

# View logs
base44 logs --function aria-chat

# Redeploy
base44 functions deploy functions/aria-chat.js --force
```

**Problem**: Entities not created
```bash
# List entities
base44 entities list

# Validate entity
base44 entities validate entities/Document.json

# Redeploy
base44 entities deploy entities/Document.json --force
```

### Frontend Issues

**Problem**: Build fails
```bash
# Install dependencies
npm install

# Try local build
npm run build

# Check for errors
```

**Problem**: API calls fail (CORS)
```bash
# Add your domain to CORS
base44 cors add https://your-domain.com

# List CORS origins
base44 cors list
```

**Problem**: Environment variable not working
1. Go to Vercel dashboard
2. Project Settings → Environment Variables
3. Add: `VITE_API_BASE_URL` = `https://[your-project].base44.run`
4. Redeploy: `vercel --prod`

---

## Next Steps

### 1. Try ARIA Commands

Open ARIA chat and try:

- **"What can you do?"** - See capabilities
- **"Organize my documents"** - Auto-organization
- **"Summarize my documents"** - Get summaries
- **"Generate a briefing on [topic]"** - Create report

### 2. Use Generation Dashboard

1. Go to Generate tab
2. Select "Briefing" or "Research"
3. Enter a topic or question
4. Click "Generate"
5. View comprehensive AI-generated report

### 3. Upload Documents

1. Go to Documents tab
2. Click Upload
3. Select file
4. Enable "auto_process" for AI analysis
5. View extracted content and summary

### 4. Invite Team Members

```bash
# Create workspace member
base44 entities create WorkspaceMember '{
  "workspace_id": "ws-123",
  "user_email": "teammate@example.com",
  "role": "member"
}'
```

---

## Custom Domain (Optional)

### For Frontend (Vercel)

1. Go to Vercel dashboard → Your project → Settings → Domains
2. Add domain: `app.signal87.ai`
3. In your DNS provider (IONOS), add CNAME:
   ```
   Name: app
   Type: CNAME
   Value: cname.vercel-dns.com
   ```
4. Wait 5-10 minutes for DNS propagation
5. Update CORS: `base44 cors add https://app.signal87.ai`

### For Backend (Base44)

Base44 provides automatic HTTPS endpoint. To use custom domain:
1. Contact Base44 support
2. Or use Vercel's API proxy (see DEPLOYMENT.md)

---

## Monitoring

### View Logs

```bash
# Backend logs
base44 logs --function aria-chat --follow

# Error logs only
base44 logs --level error

# View last 100 lines
base44 logs --tail 100
```

### Check Usage

```bash
# View function invocations
base44 analytics functions

# View entity usage
base44 analytics entities

# View storage usage
base44 analytics storage
```

---

## Performance Tips

### 1. Enable Caching

```javascript
// In your functions
export const config = {
  cache: {
    ttl: 3600 // 1 hour
  }
};
```

### 2. Use Haiku for Simple Tasks

```javascript
// In aria-core.js, use Haiku for categorization:
model: 'claude-haiku-4-20250514'
```

### 3. Optimize Document Processing

```javascript
// Process in batches
const batches = chunk(documents, 10);
for (const batch of batches) {
  await Promise.all(batch.map(processDocument));
}
```

---

## Getting Help

### Documentation

- **README.md** - Platform overview
- **DEPLOYMENT.md** - Detailed deployment guide
- **API.md** - Complete API reference
- **ENTITIES.md** - Database schema
- **SUBMISSION_GUIDE.md** - Submission instructions

### Support

- **Base44**: support@base44.dev
- **Vercel**: https://vercel.com/support
- **Signal87**: Your team

### Community

- Join Base44 Discord
- Check Base44 docs: https://docs.base44.dev

---

## Summary

You now have:

✅ **Backend** deployed on Base44
✅ **Frontend** deployed on Vercel
✅ **ARIA** ready to use
✅ **8 Entities** for data storage
✅ **7 API Endpoints** for operations
✅ **Complete UI** with dark theme

**Total deployment time**: ~15 minutes

**Start using ARIA now!** 🚀

---

## What's Next?

1. **Upload documents** - Try uploading some PDFs
2. **Ask ARIA** - "Organize my documents by category"
3. **Generate briefings** - Create AI-powered reports
4. **Conduct research** - Ask complex questions across all documents
5. **Invite team** - Add workspace members
6. **Monitor usage** - Check logs and analytics
7. **Collect feedback** - ARIA learns from user feedback

**Congratulations on deploying Signal87 AI Platform!** 🎉
