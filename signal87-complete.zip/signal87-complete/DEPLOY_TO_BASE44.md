# 🚀 Deploy to Base44 - Quick Commands

## One-Line Deployment

```bash
cd /home/user/signal87-complete && ./deploy.sh
```

That's it! The script will deploy everything automatically.

---

## Manual Deployment (If Script Doesn't Work)

### Step 1: Install Base44 CLI

```bash
npm install -g @base44/cli
base44 login
```

### Step 2: Initialize Project

```bash
cd /home/user/signal87-complete
base44 init
# Select or create project: signal87-ai
```

### Step 3: Deploy Entities (Copy-Paste This Block)

```bash
base44 entities deploy entities/Document.json && \
base44 entities deploy entities/Folder.json && \
base44 entities deploy entities/Workspace.json && \
base44 entities deploy entities/WorkspaceMember.json && \
base44 entities deploy entities/ResearchReport.json && \
base44 entities deploy entities/TrainingData.json && \
base44 entities deploy entities/AuditLog.json && \
base44 entities deploy entities/AriaFeedback.json
```

### Step 4: Deploy Functions (Copy-Paste This Block)

```bash
base44 functions deploy functions/aria-core.js && \
base44 functions deploy functions/aria-chat.js --route /api/aria/chat && \
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch && \
base44 functions deploy functions/aria-research.js --route /api/aria/research && \
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing && \
base44 functions deploy functions/aria-upload.js --route /api/aria/upload && \
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback && \
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities
```

### Step 5: Test Deployment

```bash
# Get your project URL
base44 info

# Test capabilities endpoint
curl https://[your-project].base44.run/api/aria/capabilities
```

### Step 6: Configure CORS

```bash
base44 cors add https://signal87-ai.vercel.app
base44 cors add http://localhost:3000
```

---

## Alternative: Drag-and-Drop to Base44 Dashboard

If Base44 has a web interface:

1. **Go to Base44 Dashboard**: https://base44.dev/dashboard
2. **Create New Project**: "signal87-ai"
3. **Upload Entities**:
   - Drag all files from `entities/` folder
4. **Upload Functions**:
   - Drag all files from `functions/` folder
   - Set routes for each endpoint (see base44.json)
5. **Configure**:
   - Set CORS origins
   - Verify environment variables

---

## Using Base44 CLI Commands Directly

### Deploy Everything with One Config

If Base44 supports config-based deployment:

```bash
base44 deploy --config base44.json
```

### Or Deploy Individually

**Entities:**
```bash
cd /home/user/signal87-complete
for file in entities/*.json; do
  base44 entities deploy "$file"
done
```

**Functions:**
```bash
# Core
base44 functions deploy functions/aria-core.js

# Endpoints
base44 functions deploy functions/aria-chat.js --route /api/aria/chat
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch
base44 functions deploy functions/aria-research.js --route /api/aria/research
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing
base44 functions deploy functions/aria-upload.js --route /api/aria/upload
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities
```

---

## Verify Deployment

```bash
# List deployed entities
base44 entities list

# List deployed functions
base44 functions list

# Test endpoint
curl https://[your-project].base44.run/api/aria/capabilities

# View logs
base44 logs --function aria-chat --tail 50
```

---

## Get Your API Endpoint

After deployment, your API will be available at:

```
https://[your-project-id].base44.run
```

Use this URL in your Vercel frontend environment variable:

```
VITE_API_BASE_URL=https://[your-project-id].base44.run
```

---

## Troubleshooting

### Issue: "base44: command not found"

```bash
npm install -g @base44/cli
```

### Issue: "Not authenticated"

```bash
base44 login
```

### Issue: Entity deployment fails

```bash
# Validate entity first
base44 entities validate entities/Document.json

# Force redeploy
base44 entities deploy entities/Document.json --force
```

### Issue: Function deployment fails

```bash
# Check syntax
deno check functions/aria-chat.js

# View error logs
base44 logs --function aria-chat --level error

# Force redeploy
base44 functions deploy functions/aria-chat.js --force
```

---

## What Gets Deployed

✅ **8 Entities** - Complete database schema
✅ **8 Functions** - All ARIA API endpoints
✅ **CORS** - Configured for your frontend
✅ **Routes** - All API routes mapped
✅ **Config** - Project configuration

---

## After Deployment

1. **Note your API endpoint**: `https://[project].base44.run`
2. **Test**: `curl https://[project].base44.run/api/aria/capabilities`
3. **Configure frontend**: Add API_BASE_URL to Vercel
4. **Deploy frontend**: See QUICKSTART.md
5. **Start using ARIA!** 🎉

---

## Need Help?

- **Base44 Docs**: https://docs.base44.dev
- **Base44 Support**: support@base44.dev
- **Signal87 Docs**: See README.md, DEPLOYMENT.md, API.md

---

## Files Reference

All files are in `/home/user/signal87-complete/`:

- **base44.json** - Project configuration
- **deploy.sh** - Automated deployment script
- **functions/** - 8 backend functions
- **entities/** - 8 database schemas
- **docs/** - Complete documentation

---

**Ready to deploy?**

```bash
cd /home/user/signal87-complete
./deploy.sh
```

🚀 Let's go!
