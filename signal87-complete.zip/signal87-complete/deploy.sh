#!/bin/bash

# Signal87 Base44 Deployment Script
# This script deploys the complete Signal87 AI Platform to Base44

set -e  # Exit on error

echo "🚀 Signal87 Base44 Deployment Script"
echo "======================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if base44 CLI is installed
if ! command -v base44 &> /dev/null; then
    echo -e "${RED}❌ Base44 CLI not found${NC}"
    echo "Install it with: npm install -g @base44/cli"
    exit 1
fi

echo -e "${GREEN}✓ Base44 CLI found${NC}"

# Check if logged in
if ! base44 whoami &> /dev/null; then
    echo -e "${RED}❌ Not logged in to Base44${NC}"
    echo "Login with: base44 login"
    exit 1
fi

echo -e "${GREEN}✓ Logged in to Base44${NC}"
echo ""

# Deploy entities
echo -e "${BLUE}📦 Deploying Entities...${NC}"
echo "-------------------------"

entities=(
    "Document"
    "Folder"
    "Workspace"
    "WorkspaceMember"
    "ResearchReport"
    "TrainingData"
    "AuditLog"
    "AriaFeedback"
)

for entity in "${entities[@]}"; do
    echo -n "  Deploying $entity... "
    if base44 entities deploy "entities/$entity.json" --silent; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${RED}✗${NC}"
        exit 1
    fi
done

echo -e "${GREEN}✓ All entities deployed${NC}"
echo ""

# Deploy functions
echo -e "${BLUE}⚡ Deploying Functions...${NC}"
echo "-------------------------"

# Deploy core first (it's imported by others)
echo -n "  Deploying aria-core... "
if base44 functions deploy functions/aria-core.js --silent; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    exit 1
fi

# Deploy API endpoints
declare -A functions=(
    ["aria-chat"]="/api/aria/chat"
    ["aria-documents"]="/api/aria/documents/batch"
    ["aria-research"]="/api/aria/research"
    ["aria-briefing"]="/api/aria/briefing"
    ["aria-upload"]="/api/aria/upload"
    ["aria-feedback"]="/api/aria/feedback"
    ["aria-capabilities"]="/api/aria/capabilities"
)

for func in "${!functions[@]}"; do
    route="${functions[$func]}"
    echo -n "  Deploying $func ($route)... "
    if base44 functions deploy "functions/$func.js" --route "$route" --silent; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${RED}✗${NC}"
        exit 1
    fi
done

echo -e "${GREEN}✓ All functions deployed${NC}"
echo ""

# Get project info
echo -e "${BLUE}📋 Deployment Info${NC}"
echo "-------------------------"

PROJECT_URL=$(base44 info --format json | jq -r '.url')
if [ -n "$PROJECT_URL" ]; then
    echo -e "  API Endpoint: ${GREEN}$PROJECT_URL${NC}"
else
    echo -e "  API Endpoint: ${GREEN}https://[your-project].base44.run${NC}"
fi

echo ""
echo -e "${BLUE}🧪 Testing Deployment...${NC}"
echo "-------------------------"

# Test capabilities endpoint
echo -n "  Testing capabilities endpoint... "
if [ -n "$PROJECT_URL" ]; then
    if curl -s "$PROJECT_URL/api/aria/capabilities" > /dev/null; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${RED}✗ (may need authentication)${NC}"
    fi
else
    echo -e "${BLUE}⊘ (test manually)${NC}"
fi

echo ""
echo -e "${GREEN}✅ Deployment Complete!${NC}"
echo "======================================"
echo ""
echo "Next steps:"
echo "  1. Note your API endpoint above"
echo "  2. Configure CORS for your frontend:"
echo "     base44 cors add https://your-frontend-domain.com"
echo "  3. Deploy frontend to Vercel with API endpoint"
echo "  4. Test ARIA chat in your app"
echo ""
echo "Documentation:"
echo "  • README.md - Platform overview"
echo "  • QUICKSTART.md - 15-minute setup guide"
echo "  • API.md - API reference"
echo ""
echo "🎉 Signal87 AI Platform is ready!"
