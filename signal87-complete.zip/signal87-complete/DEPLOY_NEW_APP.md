# 🚀 Deploy Signal87 as a Brand New Application

This guide will help you deploy Signal87 AI Platform with ARIA as a **completely new application**, separate from any existing apps.

---

## Overview

We'll create:
- **New Base44 Project**: `signal87-platform` (backend + database)
- **New Vercel Project**: `signal87-platform` (frontend)
- **New Domain** (optional): `platform.signal87.ai` or `aria.signal87.ai`

**Total Time**: 20-30 minutes

---

## Part 1: Deploy Backend to Base44 (New Project)

### Step 1: Install Base44 CLI

```bash
# Install Base44 CLI globally
npm install -g @base44/cli

# Verify installation
base44 --version
```

### Step 2: Login to Base44

```bash
base44 login
```

This will open your browser to authenticate.

### Step 3: Create New Base44 Project

```bash
# Navigate to the Signal87 complete folder
cd /home/user/signal87-complete

# Initialize new Base44 project
base44 init

# You'll be prompted:
# ? Create new project or select existing? → Choose "Create new project"
# ? Project name: → Enter "signal87-platform" (or your preferred name)
# ? Runtime: → Select "Deno"
# ? Region: → Select "us-east-1" (or closest to your users)
```

**✅ Your new Base44 project is created!**

### Step 4: Deploy Database Schemas (8 Entities)

Copy and paste this entire block:

```bash
echo "📦 Deploying entities..."
base44 entities deploy entities/Document.json && \
base44 entities deploy entities/Folder.json && \
base44 entities deploy entities/Workspace.json && \
base44 entities deploy entities/WorkspaceMember.json && \
base44 entities deploy entities/ResearchReport.json && \
base44 entities deploy entities/TrainingData.json && \
base44 entities deploy entities/AuditLog.json && \
base44 entities deploy entities/AriaFeedback.json && \
echo "✅ All entities deployed!"
```

**Verify:**
```bash
base44 entities list
```

You should see all 8 entities listed.

### Step 5: Deploy Backend Functions (8 Functions)

Copy and paste this entire block:

```bash
echo "⚡ Deploying functions..."
base44 functions deploy functions/aria-core.js && \
base44 functions deploy functions/aria-chat.js --route /api/aria/chat && \
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch && \
base44 functions deploy functions/aria-research.js --route /api/aria/research && \
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing && \
base44 functions deploy functions/aria-upload.js --route /api/aria/upload && \
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback && \
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities && \
echo "✅ All functions deployed!"
```

**Verify:**
```bash
base44 functions list
```

You should see all 7 API endpoints.

### Step 6: Get Your API Endpoint

```bash
base44 info
```

**Note this URL** - you'll need it for the frontend:
```
https://[your-project-id].base44.run
```

For example: `https://signal87-platform-abc123.base44.run`

### Step 7: Test Your Backend

```bash
# Replace [your-project-id] with your actual project ID
curl https://[your-project-id].base44.run/api/aria/capabilities
```

You should see JSON response with ARIA's capabilities.

**✅ Backend deployed successfully!**

---

## Part 2: Deploy Frontend to Vercel (New Project)

### Step 8: Push Code to New GitHub Repository

```bash
# Navigate to the project
cd /home/user/signal87-complete

# Initialize git (if not already)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Signal87 AI Platform with ARIA"

# Create new GitHub repository (via GitHub web interface):
# 1. Go to https://github.com/new
# 2. Repository name: "signal87-platform" (or your preferred name)
# 3. Make it Private
# 4. Don't initialize with README (we already have files)
# 5. Click "Create repository"

# Add remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/signal87-platform.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**✅ Code is now on GitHub!**

### Step 9: Deploy to Vercel

#### Option A: Via Vercel Dashboard (Recommended)

1. **Go to Vercel**: https://vercel.com/new

2. **Import Git Repository**:
   - Click "Import Git Repository"
   - Select your GitHub account
   - Find "signal87-platform" repository
   - Click "Import"

3. **Configure Project**:
   ```
   Project Name: signal87-platform
   Framework Preset: Vite
   Root Directory: ./
   Build Command: npm run build
   Output Directory: dist
   Install Command: npm install
   ```

4. **Add Environment Variables**:
   Click "Environment Variables" and add:
   ```
   Name: VITE_API_BASE_URL
   Value: https://[your-project-id].base44.run
   ```
   (Use the API endpoint from Step 6)

5. **Deploy**:
   - Click "Deploy"
   - Wait 2-3 minutes for build

6. **Get Your Frontend URL**:
   After deployment, you'll get:
   ```
   https://signal87-platform.vercel.app
   ```

#### Option B: Via Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
cd /home/user/signal87-complete
vercel

# Follow prompts:
# ? Set up and deploy? → Yes
# ? Which scope? → Select your account
# ? Link to existing project? → No
# ? What's your project's name? → signal87-platform
# ? In which directory is your code located? → ./
# ? Want to override settings? → Yes
# ? Build Command: → npm run build
# ? Output Directory: → dist
# ? Development Command: → npm run dev

# Add environment variable
vercel env add VITE_API_BASE_URL production
# Enter value: https://[your-project-id].base44.run

# Deploy to production
vercel --prod
```

**✅ Frontend deployed successfully!**

---

## Part 3: Configure Integration

### Step 10: Configure CORS

Allow your Vercel frontend to access Base44 backend:

```bash
# Add your Vercel domain to CORS
base44 cors add https://signal87-platform.vercel.app

# Add localhost for testing
base44 cors add http://localhost:3000
base44 cors add http://localhost:5173

# Verify
base44 cors list
```

### Step 11: Test the Complete Application

1. **Visit your app**: `https://signal87-platform.vercel.app`

2. **You should see**:
   - Black-themed landing page
   - "Signal87" logo with purple gradient
   - "AI-Powered Document Intelligence" headline

3. **Click "Get Started"**:
   - Should go to `/dashboard`
   - See dark-themed dashboard with sidebar

4. **Click ARIA button** (bottom-right, purple gradient):
   - Chat panel should open
   - Type: "What can you do?"
   - ARIA should respond with capabilities

5. **Try Generation Dashboard**:
   - Click "Generate" in sidebar
   - Select "Briefing" or "Research"
   - Enter a topic
   - Click "Generate" (will need documents first)

**✅ Application is working!**

---

## Part 4: Add Custom Domain (Optional)

### Step 12: Configure Custom Domain

If you want `platform.signal87.ai` or `aria.signal87.ai`:

#### In Vercel:

1. Go to your project settings: https://vercel.com/[your-account]/signal87-platform/settings/domains

2. Add domain:
   ```
   platform.signal87.ai
   ```
   or
   ```
   aria.signal87.ai
   ```

3. Vercel will show you DNS records to add

#### In IONOS (or your DNS provider):

1. Login to IONOS DNS management

2. Add CNAME record:
   ```
   Type: CNAME
   Name: platform (or aria)
   Value: cname.vercel-dns.com
   TTL: 3600
   ```

3. Save changes

4. Wait 5-15 minutes for DNS propagation

5. Verify in Vercel - should show green checkmark

#### Update CORS:

```bash
base44 cors add https://platform.signal87.ai
# or
base44 cors add https://aria.signal87.ai
```

**✅ Custom domain configured!**

---

## Part 5: Initial Setup

### Step 13: Create Your First Workspace

The app needs a workspace to organize documents. You can create one via the API or directly in Base44:

```bash
# Create default workspace
curl -X POST https://[your-project-id].base44.run/api/workspaces \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Workspace",
    "slug": "my-workspace",
    "owner_email": "your-email@example.com"
  }'
```

Or create via Base44 dashboard if available.

### Step 14: Test Document Upload

1. Go to Documents tab
2. Click "Upload" button
3. Select a PDF file
4. Upload should work (may need authentication setup)

### Step 15: Test ARIA Commands

Try these commands in ARIA chat:

- "What can you do?"
- "Hello ARIA"
- "Tell me about your capabilities"

---

## Deployment Summary

### ✅ What You've Deployed

**Backend (Base44)**:
- Project: `signal87-platform`
- URL: `https://[project-id].base44.run`
- 8 Entities (database)
- 8 Functions (API endpoints)
- CORS configured

**Frontend (Vercel)**:
- Project: `signal87-platform`
- URL: `https://signal87-platform.vercel.app`
- (Optional) Custom: `https://platform.signal87.ai`
- Environment variables configured
- Connected to Base44 backend

**GitHub**:
- Repository: `signal87-platform`
- Auto-deploy on push to main

---

## Environment URLs

### Development
```
Local Frontend: http://localhost:3000
→ Connected to: https://[project-id].base44.run
```

### Production
```
Frontend: https://signal87-platform.vercel.app
OR: https://platform.signal87.ai
→ Connected to: https://[project-id].base44.run
```

### Your Existing Site (Unchanged)
```
Production: https://www.signal87.ai
App: https://app.signal87.ai (if configured)
→ These remain completely separate!
```

---

## Next Steps

### 1. Set Up Authentication

Currently the app needs Base44 authentication configured. Check Base44 docs for:
- Email/password authentication
- OAuth (Google, GitHub)
- Magic links

### 2. Upload Sample Documents

1. Create some test PDFs
2. Upload via Documents tab
3. Try ARIA commands on them

### 3. Try ARIA Features

**Document Operations**:
- "Organize my documents by category"
- "Summarize all my documents"
- "Delete documents from last year"

**Research**:
- "Research mentions of [keyword] across all documents"
- "Find all documents about [topic]"

**Briefings**:
- "Generate a briefing on [topic]"
- "Create an executive summary of my documents"

### 4. Invite Team Members

```bash
# Create workspace member via API
curl -X POST https://[project-id].base44.run/api/workspaces/members \
  -H "Content-Type: application/json" \
  -d '{
    "workspace_id": "ws-123",
    "user_email": "teammate@example.com",
    "role": "member"
  }'
```

### 5. Monitor and Maintain

**View Logs**:
```bash
base44 logs --function aria-chat --tail 50
base44 logs --level error
```

**Check Usage**:
```bash
base44 analytics
```

**Update Code**:
```bash
# Make changes
git add .
git commit -m "Update feature"
git push origin main
# Vercel auto-deploys frontend

# For backend:
base44 functions deploy functions/aria-chat.js --force
```

---

## Troubleshooting

### Issue: "CORS error" in browser console

```bash
base44 cors add https://your-vercel-domain.vercel.app
```

### Issue: "Authentication required"

Check Base44 authentication setup:
```bash
base44 auth status
```

### Issue: ARIA not responding

1. Check backend logs:
```bash
base44 logs --function aria-chat --tail 20
```

2. Test endpoint directly:
```bash
curl https://[project-id].base44.run/api/aria/capabilities
```

3. Check environment variables in Vercel

### Issue: Build fails on Vercel

1. Check Node version (should be 18+)
2. Verify package.json dependencies
3. Check build logs in Vercel dashboard

### Issue: Functions timeout

Increase timeout in base44.json:
```json
{
  "functions": {
    "aria-research": {
      "timeout": 300000
    }
  }
}
```

Then redeploy:
```bash
base44 functions deploy functions/aria-research.js --force
```

---

## Complete Command Reference

### Backend Commands
```bash
# Deploy entity
base44 entities deploy entities/Document.json

# Deploy function
base44 functions deploy functions/aria-chat.js --route /api/aria/chat

# View logs
base44 logs --function aria-chat --follow

# List entities
base44 entities list

# List functions
base44 functions list

# Project info
base44 info
```

### Frontend Commands
```bash
# Local development
npm run dev

# Build
npm run build

# Deploy to Vercel
vercel --prod

# View Vercel logs
vercel logs
```

---

## Files Location

All files are in:
```
/home/user/signal87-complete/
```

**Key files**:
- `base44.json` - Base44 configuration
- `deploy.sh` - Automated deployment script
- `DEPLOY_NEW_APP.md` - This file
- `functions/` - Backend code (8 files)
- `entities/` - Database schemas (8 files)
- `src/` - Frontend code
- `docs/` - Complete documentation

---

## Support Resources

### Documentation
- **README.md** - Platform overview and architecture
- **DEPLOYMENT.md** - Detailed deployment guide
- **API.md** - Complete API reference with examples
- **ENTITIES.md** - Database schema documentation
- **QUICKSTART.md** - Quick 15-minute setup

### External Support
- **Base44**: https://docs.base44.dev
- **Vercel**: https://vercel.com/docs
- **GitHub**: https://docs.github.com

---

## Success Checklist

Before considering deployment complete:

- [ ] Base44 CLI installed and logged in
- [ ] New Base44 project created (`signal87-platform`)
- [ ] All 8 entities deployed
- [ ] All 8 functions deployed
- [ ] Backend tested (`/api/aria/capabilities` works)
- [ ] Code pushed to new GitHub repository
- [ ] Vercel project created
- [ ] Environment variable configured (VITE_API_BASE_URL)
- [ ] Frontend deployed and accessible
- [ ] CORS configured for Vercel domain
- [ ] ARIA chat working
- [ ] (Optional) Custom domain configured

---

## What Makes This a New App

This deployment is **completely separate** from your existing signal87.ai:

| Aspect | Existing App | New App |
|--------|-------------|---------|
| Backend | Your current setup | New Base44 project |
| Database | Your current data | Fresh database |
| Frontend | app.signal87.ai | signal87-platform.vercel.app |
| Code | Existing codebase | New repository |
| Domain | signal87.ai | platform.signal87.ai (optional) |

**No conflicts!** Both can run simultaneously.

---

## Congratulations! 🎉

You've successfully deployed Signal87 AI Platform with ARIA as a brand new application!

**Your new app is live at**:
- Frontend: `https://signal87-platform.vercel.app`
- Backend: `https://[project-id].base44.run`

**Ready to use ARIA!**

Start by:
1. Opening your app
2. Clicking the ARIA button
3. Asking: "What can you do?"

Enjoy your AI-powered document intelligence platform! 🚀
