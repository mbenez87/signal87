/**
 * ARIA Research Endpoint
 * POST /api/aria/research
 * Deep research and analysis across multiple documents
 */

import base44 from '@base44/sdk';
import { AriaCapabilities } from './aria-core.js';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse request
    const { query, document_ids, depth, include_web_search } = await req.json();

    if (!query) {
      return Response.json({ error: 'Query required' }, { status: 400 });
    }

    const capabilities = new AriaCapabilities(user);

    // Conduct deep research
    const startTime = Date.now();
    const result = await capabilities.conductDeepResearch({
      query,
      document_ids: document_ids || [],
      depth: depth || 'comprehensive',
      params: {
        include_web_search: include_web_search || false,
        user_email: user.email
      }
    });
    const executionTime = Date.now() - startTime;

    return Response.json({
      success: true,
      research_id: result.research_id,
      query: result.query,
      documents_analyzed: result.documents_analyzed,
      findings: result.findings,
      citations: result.citations,
      execution_time: executionTime
    });

  } catch (error) {
    console.error('Research error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
