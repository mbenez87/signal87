/**
 * ARIA Feedback Endpoint
 * POST /api/aria/feedback
 * Collect user feedback on Aria responses for training
 */

import base44 from '@base44/sdk';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse request
    const { session_id, message_id, rating, feedback_text, helpful } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Store feedback
    const feedback = await base44.asServiceRole.entities.AriaFeedback.create({
      user_id: user.id,
      user_email: user.email,
      session_id,
      message_id: message_id || null,
      rating: rating || null, // 1-5 stars
      feedback_text: feedback_text || null,
      helpful: helpful || null, // boolean
      timestamp: new Date().toISOString()
    });

    // Update related training data with feedback
    try {
      const trainingRecords = await base44.asServiceRole.entities.TrainingData.filter({
        session_id: session_id
      });

      for (const record of trainingRecords) {
        await base44.asServiceRole.entities.TrainingData.updateById(record.id, {
          user_feedback: {
            rating,
            feedback_text,
            helpful,
            timestamp: new Date().toISOString()
          }
        });
      }
    } catch (trainingUpdateError) {
      console.warn('Could not update training data:', trainingUpdateError);
      // Don't fail the request if training data update fails
    }

    return Response.json({
      success: true,
      message: 'Feedback recorded',
      feedback_id: feedback.id
    });

  } catch (error) {
    console.error('Feedback error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
