/**
 * ARIA Chat Endpoint
 * POST /api/aria/chat
 * Main conversational interface for Aria
 */

import base44 from '@base44/sdk';
import { AriaAgent } from './aria-core.js';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse request
    const { message, context, session_id } = await req.json();

    if (!message) {
      return Response.json({ error: 'Message required' }, { status: 400 });
    }

    // Initialize Aria
    const aria = new AriaAgent({
      user,
      sessionId: session_id || `session-${Date.now()}`
    });

    // Process request
    const startTime = Date.now();
    const response = await aria.processRequest(message, {
      ...context,
      user_email: user.email,
      workspace_id: context?.workspace_id || 'default'
    });
    const executionTime = Date.now() - startTime;

    return Response.json({
      success: true,
      message: response.message,
      actions_performed: response.results?.length || 0,
      session_id: aria.sessionId,
      execution_time: executionTime,
      results: response.results
    });

  } catch (error) {
    console.error('Aria chat error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
