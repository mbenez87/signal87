/**
 * ARIA Briefing Endpoint
 * POST /api/aria/briefing
 * Generate comprehensive analytical briefings
 */

import base44 from '@base44/sdk';
import { AriaCapabilities } from './aria-core.js';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse request
    const { topic, document_ids, briefing_type } = await req.json();

    if (!topic) {
      return Response.json({ error: 'Topic required' }, { status: 400 });
    }

    const capabilities = new AriaCapabilities(user);

    // Generate briefing
    const startTime = Date.now();
    const result = await capabilities.generateBriefing({
      topic,
      document_ids: document_ids || [],
      briefing_type: briefing_type || 'analytical',
      params: {
        user_email: user.email
      }
    });
    const executionTime = Date.now() - startTime;

    return Response.json({
      success: true,
      briefing_id: result.briefing_id,
      topic: result.topic,
      briefing_type: result.briefing_type,
      documents_used: result.documents_used,
      content: result.content,
      document_id: result.document_id,
      execution_time: executionTime
    });

  } catch (error) {
    console.error('Briefing error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
