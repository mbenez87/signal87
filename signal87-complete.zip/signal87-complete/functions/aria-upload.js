/**
 * ARIA Upload Endpoint
 * POST /api/aria/upload
 * Upload documents with automatic AI processing
 */

import base44 from '@base44/sdk';
import { AriaCapabilities } from './aria-core.js';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse multipart form data
    const formData = await req.formData();
    const file = formData.get('file');
    const workspace_id = formData.get('workspace_id') || 'default';
    const auto_process = formData.get('auto_process') === 'true';

    if (!file) {
      return Response.json({ error: 'File required' }, { status: 400 });
    }

    // Upload file to storage
    const uploadResult = await base44.integrations.Core.UploadFile({ file });

    // Create document record
    const document = await base44.asServiceRole.entities.Document.create({
      title: file.name,
      file_url: uploadResult.file_url,
      file_type: file.type,
      file_size: file.size,
      workspace_id: workspace_id,
      created_by: user.email,
      processing_status: auto_process ? 'processing' : 'completed',
      created_at: new Date().toISOString()
    });

    // Auto-process with Aria if requested
    if (auto_process) {
      const capabilities = new AriaCapabilities(user);

      try {
        // Process upload (extract content, generate summary, auto-categorize)
        const processResult = await capabilities.processUpload({
          document_id: document.id,
          file_url: uploadResult.file_url,
          file_name: file.name,
          params: { workspace_id }
        });

        // Update document with processing results
        await base44.asServiceRole.entities.Document.updateById(document.id, {
          extracted_content: processResult.extracted_content,
          ai_summary: processResult.summary,
          category: processResult.category,
          tags: processResult.tags,
          processing_status: 'completed'
        });

        return Response.json({
          success: true,
          document_id: document.id,
          title: document.title,
          file_url: uploadResult.file_url,
          auto_processed: true,
          summary: processResult.summary,
          category: processResult.category,
          suggested_folder: processResult.suggested_folder,
          tags: processResult.tags
        });

      } catch (processingError) {
        // Mark as failed but still return document
        await base44.asServiceRole.entities.Document.updateById(document.id, {
          processing_status: 'failed',
          processing_error: processingError.message
        });

        return Response.json({
          success: true,
          document_id: document.id,
          title: document.title,
          file_url: uploadResult.file_url,
          auto_processed: false,
          processing_error: processingError.message
        });
      }
    }

    return Response.json({
      success: true,
      document_id: document.id,
      title: document.title,
      file_url: uploadResult.file_url,
      auto_processed: false
    });

  } catch (error) {
    console.error('Upload error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
