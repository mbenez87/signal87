/**
 * ARIA CORE AGENT SYSTEM
 * Complete autonomous agent for Signal87 platform
 *
 * Deploy to: Deno Deploy
 * Base44 SDK: @base44/sdk@0.8.4
 */

import base44 from '@base44/sdk';

// ============================================================================
// ARIA AGENT - Main Orchestrator
// ============================================================================

export class AriaAgent {
  constructor(userContext) {
    this.user = userContext;
    this.sessionId = `session-${Date.now()}`;
    this.conversationHistory = [];
  }

  async processRequest(userInput, context = {}) {
    try {
      // Add to conversation history
      this.conversationHistory.push({
        role: 'user',
        content: userInput,
        timestamp: new Date().toISOString()
      });

      // 1. Analyze user intent
      const intent = await this.analyzeIntent(userInput, context);

      // 2. Plan actions
      const actionPlan = await this.planActions(intent, context);

      // 3. Execute actions
      const results = await this.executeActions(actionPlan);

      // 4. Generate response
      const response = await this.generateResponse(results, intent);

      // 5. Log for training
      await this.logForTraining(userInput, intent, actionPlan, results, response);

      // Add to conversation history
      this.conversationHistory.push({
        role: 'assistant',
        content: response.message,
        timestamp: new Date().toISOString(),
        actions: results
      });

      return {
        success: true,
        message: response.message,
        actions_performed: results.filter(r => r.success).length,
        actions_failed: results.filter(r => !r.success).length,
        results: results,
        session_id: this.sessionId
      };

    } catch (error) {
      console.error('Aria processing error:', error);
      return {
        success: false,
        error: error.message,
        session_id: this.sessionId
      };
    }
  }

  async analyzeIntent(userInput, context) {
    const systemPrompt = `You are Aria, an autonomous AI agent with full platform control.

Your capabilities:
- File operations: delete, move, rename, organize files and folders
- Document actions: apply signatures, generate summaries, extract insights
- Deep research: comprehensive analysis across multiple documents
- Report generation: detailed briefings with citations
- Platform automation: batch operations, workflows

User context:
- Workspace: ${context.workspace_id || 'default'}
- Current folder: ${context.folder_id || 'root'}
- Selected documents: ${context.selected_documents?.length || 0}

Recent conversation:
${this.conversationHistory.slice(-5).map(m => `${m.role}: ${m.content}`).join('\n')}

User request: "${userInput}"

Analyze this request and determine:
1. primary_action: Main action to perform (delete_files, move_files, apply_signature, generate_summary, deep_research, generate_briefing, organize_documents, upload_document, custom)
2. entities: Specific documents/folders involved
3. parameters: Required parameters for the action
4. complexity: simple/moderate/complex
5. requires_research: Does this need deep document analysis?
6. reasoning: Why you chose this interpretation

Output as JSON.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: systemPrompt,
      model: 'claude-sonnet-4-20250514',
      response_json_schema: {
        type: 'object',
        properties: {
          primary_action: { type: 'string' },
          entities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string' },
                type: { type: 'string' },
                title: { type: 'string' }
              }
            }
          },
          parameters: { type: 'object' },
          complexity: { type: 'string', enum: ['simple', 'moderate', 'complex'] },
          requires_research: { type: 'boolean' },
          reasoning: { type: 'string' }
        },
        required: ['primary_action', 'entities', 'parameters', 'complexity', 'requires_research', 'reasoning']
      }
    });

    return JSON.parse(response.output);
  }

  async planActions(intent, context) {
    const actions = [];

    // Map intent to concrete actions
    switch (intent.primary_action) {
      case 'delete_files':
        intent.entities.forEach(entity => {
          actions.push({
            type: 'delete_document',
            document_id: entity.id,
            params: intent.parameters
          });
        });
        break;

      case 'move_files':
        actions.push({
          type: 'move_documents',
          document_ids: intent.entities.map(e => e.id),
          target_folder_id: intent.parameters.target_folder_id,
          params: intent.parameters
        });
        break;

      case 'apply_signature':
        intent.entities.forEach(entity => {
          actions.push({
            type: 'apply_signature',
            document_id: entity.id,
            signature_type: intent.parameters.signature_type || 'digital',
            params: intent.parameters
          });
        });
        break;

      case 'generate_summary':
        intent.entities.forEach(entity => {
          actions.push({
            type: 'generate_summary',
            document_id: entity.id,
            summary_type: intent.parameters.summary_type || 'executive',
            max_length: intent.parameters.max_length || 5000,
            params: intent.parameters
          });
        });
        break;

      case 'deep_research':
        actions.push({
          type: 'conduct_research',
          query: intent.parameters.research_query || intent.reasoning,
          document_ids: intent.entities.map(e => e.id),
          depth: 'comprehensive',
          params: intent.parameters
        });
        break;

      case 'generate_briefing':
        actions.push({
          type: 'generate_briefing',
          topic: intent.parameters.topic || intent.reasoning,
          document_ids: intent.entities.map(e => e.id),
          briefing_type: intent.parameters.briefing_type || 'analytical',
          params: intent.parameters
        });
        break;

      case 'organize_documents':
        actions.push({
          type: 'auto_organize',
          document_ids: intent.entities.map(e => e.id),
          strategy: intent.parameters.strategy || 'smart',
          params: intent.parameters
        });
        break;

      case 'upload_document':
        actions.push({
          type: 'process_upload',
          file_info: intent.parameters.file_info,
          params: intent.parameters
        });
        break;

      default:
        // Handle custom actions via LLM
        actions.push({
          type: 'custom_action',
          action: intent.primary_action,
          params: intent
        });
    }

    return actions;
  }

  async executeActions(actionPlan) {
    const results = [];
    const capabilities = new AriaCapabilities(this.user);

    for (const action of actionPlan) {
      try {
        let result;

        switch (action.type) {
          case 'delete_document':
            result = await capabilities.deleteDocument(action);
            break;
          case 'move_documents':
            result = await capabilities.moveDocuments(action);
            break;
          case 'apply_signature':
            result = await capabilities.applySignature(action);
            break;
          case 'generate_summary':
            result = await capabilities.generateSummary(action);
            break;
          case 'conduct_research':
            result = await capabilities.conductDeepResearch(action);
            break;
          case 'generate_briefing':
            result = await capabilities.generateBriefing(action);
            break;
          case 'auto_organize':
            result = await capabilities.autoOrganize(action);
            break;
          case 'process_upload':
            result = await capabilities.processUpload(action);
            break;
          case 'custom_action':
            result = await capabilities.handleCustomAction(action);
            break;
          default:
            result = { success: false, error: 'Unknown action type' };
        }

        results.push({ action, result, success: true });
      } catch (error) {
        console.error(`Action ${action.type} failed:`, error);
        results.push({ action, error: error.message, success: false });
      }
    }

    return results;
  }

  async generateResponse(results, intent) {
    const successfulActions = results.filter(r => r.success);
    const failedActions = results.filter(r => !r.success);

    const systemPrompt = `You are Aria. Generate a natural, conversational response about what you just did.

Intent: ${intent.primary_action}
Reasoning: ${intent.reasoning}

Actions performed:
${JSON.stringify(results, null, 2)}

Guidelines:
- Be friendly and conversational
- Confirm what was done successfully
- Explain any failures clearly
- If research/briefing was generated, summarize key findings
- Offer next steps if appropriate
- Keep it concise but informative

Generate your response:`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: systemPrompt,
      model: 'claude-sonnet-4-20250514'
    });

    return {
      message: response.output,
      actions_performed: successfulActions.length,
      actions_failed: failedActions.length
    };
  }

  async logForTraining(userInput, intent, actionPlan, results, response) {
    try {
      const trainingData = {
        timestamp: new Date().toISOString(),
        user_id: this.user.id,
        session_id: this.sessionId,
        user_input: userInput,
        intent_detected: intent,
        action_plan: actionPlan,
        actions_executed: results,
        response_generated: response.message,
        success_rate: results.filter(r => r.success).length / results.length,
        model_used: 'claude-sonnet-4-20250514',
        conversation_history: this.conversationHistory
      };

      await base44.asServiceRole.entities.TrainingData.create(trainingData);
    } catch (error) {
      console.error('Failed to log training data:', error);
    }
  }
}

// ============================================================================
// ARIA CAPABILITIES - Action Handlers
// ============================================================================

export class AriaCapabilities {
  constructor(user) {
    this.user = user;
  }

  // DELETE DOCUMENT
  async deleteDocument({ document_id, params }) {
    const document = await base44.entities.Document.getById(document_id);

    await base44.entities.Document.updateById(document_id, {
      is_trashed: true,
      trashed_date: new Date().toISOString(),
      trashed_by: this.user.email
    });

    await this.createAuditLog({
      action: 'document_deleted',
      entity_type: 'Document',
      entity_id: document_id,
      details: { title: document.title }
    });

    return {
      success: true,
      document_id,
      title: document.title,
      message: `Moved "${document.title}" to trash`
    };
  }

  // MOVE DOCUMENTS
  async moveDocuments({ document_ids, target_folder_id, params }) {
    const moved = [];

    for (const doc_id of document_ids) {
      const doc = await base44.entities.Document.getById(doc_id);

      await base44.entities.Document.updateById(doc_id, {
        folder_id: target_folder_id
      });

      moved.push({ id: doc_id, title: doc.title });
    }

    const folder = await base44.entities.Folder.getById(target_folder_id);

    await this.createAuditLog({
      action: 'documents_moved',
      entity_type: 'Document',
      entity_id: document_ids.join(','),
      details: { target_folder: folder.name, count: document_ids.length }
    });

    return {
      success: true,
      moved_count: moved.length,
      documents: moved,
      target_folder: folder.name
    };
  }

  // APPLY SIGNATURE
  async applySignature({ document_id, signature_type, params }) {
    const document = await base44.entities.Document.getById(document_id);

    const signatureData = {
      signed_by: this.user.email,
      signed_by_name: this.user.full_name,
      signed_date: new Date().toISOString(),
      signature_type: signature_type,
      signature_method: 'aria_agent',
      verification_status: 'pending'
    };

    if (signature_type === 'digital') {
      signatureData.document_hash = await this.generateDocumentHash(document.file_url);
      signatureData.signature_algorithm = 'SHA-256';
    }

    await base44.entities.Document.updateById(document_id, {
      is_signed: true,
      signed_date: signatureData.signed_date,
      signed_by: signatureData.signed_by,
      signature_verified: false,
      signature_metadata: signatureData
    });

    await this.createAuditLog({
      action: 'signature_applied',
      entity_type: 'Document',
      entity_id: document_id,
      details: { signature_type, signed_by: this.user.email }
    });

    return {
      success: true,
      document_id,
      document_title: document.title,
      signature_data: signatureData
    };
  }

  // GENERATE SUMMARY
  async generateSummary({ document_id, summary_type, max_length, params }) {
    const document = await base44.entities.Document.getById(document_id);

    const content = document.extracted_content || await this.extractContent(document.file_url);

    const summaryPrompt = `Analyze this document and generate a ${summary_type} summary.

Document Title: ${document.title}
Document Type: ${document.file_type}
Category: ${document.category}

Content:
${content.substring(0, 50000)}

Generate a ${summary_type} summary (max ${max_length} characters):
- Executive: High-level overview for leadership
- Technical: Detailed technical analysis
- Concise: Brief key points
- Comprehensive: Thorough analysis with all details

Include:
1. Main topic/purpose
2. Key findings or points
3. Important dates, numbers, or entities
4. Actionable insights
5. Recommendations (if applicable)`;

    const summary = await base44.integrations.Core.InvokeLLM({
      prompt: summaryPrompt,
      model: 'claude-sonnet-4-20250514',
      file_urls: document.file_url ? [document.file_url] : []
    });

    await base44.entities.Document.updateById(document_id, {
      ai_summary: summary.output.substring(0, 5000),
      summary_generated_date: new Date().toISOString(),
      processing_status: 'completed'
    });

    return {
      success: true,
      document_id,
      document_title: document.title,
      summary: summary.output,
      summary_type: summary_type
    };
  }

  // CONDUCT DEEP RESEARCH
  async conductDeepResearch({ query, document_ids, depth, params }) {
    const documents = await Promise.all(
      document_ids.map(id => base44.entities.Document.getById(id))
    );

    const documentContents = await Promise.all(
      documents.map(async doc => ({
        id: doc.id,
        title: doc.title,
        content: doc.extracted_content || await this.extractContent(doc.file_url),
        metadata: {
          category: doc.category,
          date: doc.created_date,
          file_type: doc.file_type
        }
      }))
    );

    const researchPrompt = `You are conducting comprehensive research. Analyze ALL provided documents thoroughly.

Research Query: "${query}"

Documents (${documents.length} total):
${documentContents.map((doc, idx) => `
Document ${idx + 1}: ${doc.title}
Category: ${doc.metadata.category}
Date: ${doc.metadata.date}

Content:
${doc.content.substring(0, 20000)}
---
`).join('\n')}

Conduct DEEP, COMPREHENSIVE research:

1. ANALYSIS:
   - What does each document say about this topic?
   - How do documents relate/contradict each other?
   - What patterns emerge across documents?

2. KEY FINDINGS:
   - Extract all relevant facts, figures, dates
   - Identify relationships between entities
   - Note any conflicts or discrepancies

3. SYNTHESIS:
   - What's the complete picture across all documents?
   - What conclusions can be drawn?
   - What's missing or unclear?

4. CITATIONS:
   - Reference specific documents for each finding
   - Include exact quotes when relevant

5. RECOMMENDATIONS:
   - What actions should be taken?
   - What additional research is needed?

Be thorough. This is deep research, not a quick summary.`;

    const research = await base44.integrations.Core.InvokeLLM({
      prompt: researchPrompt,
      model: 'claude-sonnet-4-20250514',
      add_context_from_internet: params.include_web_search || false
    });

    const researchEntity = await base44.asServiceRole.entities.ResearchReport.create({
      query: query,
      source_document_ids: document_ids,
      findings: research.output,
      generated_date: new Date().toISOString(),
      generated_by: 'aria_agent',
      research_depth: depth,
      document_count: documents.length,
      created_by: this.user.email
    });

    return {
      success: true,
      research_id: researchEntity.id,
      query: query,
      documents_analyzed: documents.length,
      findings: research.output,
      citations: documentContents.map(d => ({ id: d.id, title: d.title }))
    };
  }

  // GENERATE BRIEFING
  async generateBriefing({ topic, document_ids, briefing_type, params }) {
    const documents = await Promise.all(
      document_ids.map(id => base44.entities.Document.getById(id))
    );

    const documentContents = await Promise.all(
      documents.map(async doc => ({
        id: doc.id,
        title: doc.title,
        content: doc.extracted_content || await this.extractContent(doc.file_url),
        summary: doc.ai_summary,
        insights: doc.key_insights
      }))
    );

    const briefingPrompt = `Generate a comprehensive ${briefing_type} briefing on: "${topic}"

Source Documents (${documents.length}):
${documentContents.map((doc, idx) => `
${idx + 1}. ${doc.title}
Summary: ${doc.summary}
Key Insights: ${JSON.stringify(doc.insights)}
Content: ${doc.content.substring(0, 15000)}
---
`).join('\n')}

Generate a DETAILED, PROFESSIONAL briefing with:

## EXECUTIVE SUMMARY
High-level overview (2-3 paragraphs)

## BACKGROUND
Context and relevant history

## KEY FINDINGS
Detailed analysis of main points with citations

## ANALYSIS
In-depth examination of:
- Trends and patterns
- Risks and opportunities
- Financial implications (if applicable)
- Compliance considerations (if applicable)

## SUPPORTING DATA
Charts, figures, quotes from source documents

## CONCLUSIONS
Synthesized insights and implications

## RECOMMENDATIONS
Specific, actionable next steps

## APPENDIX
Additional details and full citations

Be thorough, analytical, and cite sources throughout.`;

    const briefing = await base44.integrations.Core.InvokeLLM({
      prompt: briefingPrompt,
      model: 'claude-sonnet-4-20250514'
    });

    const briefingDoc = await base44.asServiceRole.entities.Document.create({
      title: `${briefing_type.charAt(0).toUpperCase() + briefing_type.slice(1)} Briefing: ${topic}`,
      category: 'briefing',
      file_type: 'generated',
      extracted_content: briefing.output,
      ai_summary: briefing.output.substring(0, 5000),
      metadata: {
        generated_by: 'aria_agent',
        source_document_ids: document_ids,
        briefing_type: briefing_type,
        topic: topic,
        generated_date: new Date().toISOString()
      },
      created_by: this.user.email,
      processing_status: 'completed'
    });

    return {
      success: true,
      briefing_id: briefingDoc.id,
      topic: topic,
      briefing_type: briefing_type,
      documents_used: documents.length,
      content: briefing.output
    };
  }

  // AUTO-ORGANIZE DOCUMENTS
  async autoOrganize({ document_ids, strategy, params }) {
    const documents = await Promise.all(
      document_ids.map(id => base44.entities.Document.getById(id))
    );

    const organizationPrompt = `Analyze these documents and suggest optimal organization:

Documents:
${documents.map(doc => `
- ${doc.title}
  Category: ${doc.category}
  Type: ${doc.file_type}
  Summary: ${doc.ai_summary}
  Tags: ${JSON.stringify(doc.tags)}
`).join('\n')}

Strategy: ${strategy}

Suggest:
1. Folder structure (hierarchical)
2. Document placement in folders
3. Naming conventions
4. Tags to add
5. Categories to assign

Output as JSON with structure:
{
  "folders": [{"name": "...", "parent": null, "documents": [id1, id2]}],
  "renames": [{"document_id": "...", "new_name": "..."}],
  "tags": [{"document_id": "...", "tags": [...]}]
}`;

    const plan = await base44.integrations.Core.InvokeLLM({
      prompt: organizationPrompt,
      model: 'claude-sonnet-4-20250514',
      response_json_schema: {
        type: 'object',
        properties: {
          folders: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                parent: { type: 'string' },
                documents: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          renames: { type: 'array' },
          tags: { type: 'array' }
        }
      }
    });

    const orgPlan = JSON.parse(plan.output);
    const createdFolders = {};

    // Create folders
    for (const folder of orgPlan.folders) {
      const newFolder = await base44.asServiceRole.entities.Folder.create({
        name: folder.name,
        parent_folder_id: folder.parent ? createdFolders[folder.parent] : null,
        workspace_id: params.workspace_id,
        created_by: this.user.email
      });
      createdFolders[folder.name] = newFolder.id;

      // Move documents to folder
      for (const doc_id of folder.documents) {
        await base44.entities.Document.updateById(doc_id, {
          folder_id: newFolder.id
        });
      }
    }

    // Apply renames
    for (const rename of orgPlan.renames || []) {
      await base44.entities.Document.updateById(rename.document_id, {
        title: rename.new_name
      });
    }

    // Apply tags
    for (const tagUpdate of orgPlan.tags || []) {
      const doc = await base44.entities.Document.getById(tagUpdate.document_id);
      const existingTags = doc.tags || [];
      await base44.entities.Document.updateById(tagUpdate.document_id, {
        tags: [...new Set([...existingTags, ...tagUpdate.tags])]
      });
    }

    return {
      success: true,
      documents_organized: documents.length,
      folders_created: Object.keys(createdFolders).length,
      documents_renamed: orgPlan.renames?.length || 0,
      organization_plan: orgPlan
    };
  }

  // PROCESS UPLOAD
  async processUpload({ file_info, params }) {
    // This would be called after file is uploaded
    // Auto-extract content, categorize, organize
    return {
      success: true,
      message: 'Upload processed',
      file_info
    };
  }

  // HANDLE CUSTOM ACTION
  async handleCustomAction({ action, params }) {
    // Use LLM to handle unknown actions
    const prompt = `The user wants to: ${action}

    Parameters: ${JSON.stringify(params)}

    Determine what needs to be done and respond with instructions.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      model: 'claude-sonnet-4-20250514'
    });

    return {
      success: true,
      message: response.output
    };
  }

  // Helper methods
  async extractContent(fileUrl) {
    if (!fileUrl) return '';

    try {
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url: fileUrl
      });
      return result.output || '';
    } catch (error) {
      console.error('Content extraction failed:', error);
      return '';
    }
  }

  async generateDocumentHash(fileUrl) {
    // In production, fetch file and hash it
    return `sha256-${Date.now()}-${Math.random().toString(36).substring(7)}`;
  }

  async createAuditLog(logData) {
    try {
      await base44.asServiceRole.entities.AuditLog.create({
        ...logData,
        timestamp: new Date().toISOString(),
        user_id: this.user.id,
        user_email: this.user.email
      });
    } catch (error) {
      console.error('Audit log failed:', error);
    }
  }
}

export default { AriaAgent, AriaCapabilities };
