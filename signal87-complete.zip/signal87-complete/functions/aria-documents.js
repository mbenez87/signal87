/**
 * ARIA Document Operations Endpoint
 * POST /api/aria/documents/batch
 * Batch document operations (delete, move, sign, summarize, organize)
 */

import base44 from '@base44/sdk';
import { AriaCapabilities } from './aria-core.js';

export default async function handler(req) {
  try {
    // Authenticate user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse request
    const { operation, document_ids, parameters } = await req.json();

    if (!operation || !document_ids || !Array.isArray(document_ids)) {
      return Response.json({
        error: 'operation and document_ids array required'
      }, { status: 400 });
    }

    const capabilities = new AriaCapabilities(user);
    let results = [];

    switch (operation) {
      case 'delete':
        results = await Promise.all(
          document_ids.map(id => capabilities.deleteDocument({
            document_id: id,
            params: parameters
          }))
        );
        break;

      case 'move':
        if (!parameters?.target_folder_id) {
          return Response.json({
            error: 'target_folder_id required for move operation'
          }, { status: 400 });
        }
        results = [await capabilities.moveDocuments({
          document_ids,
          target_folder_id: parameters.target_folder_id,
          params: parameters
        })];
        break;

      case 'sign':
        results = await Promise.all(
          document_ids.map(id => capabilities.applySignature({
            document_id: id,
            signature_type: parameters?.signature_type || 'digital',
            params: parameters
          }))
        );
        break;

      case 'summarize':
        results = await Promise.all(
          document_ids.map(id => capabilities.generateSummary({
            document_id: id,
            summary_type: parameters?.summary_type || 'executive',
            max_length: parameters?.max_length || 5000,
            params: parameters
          }))
        );
        break;

      case 'organize':
        results = [await capabilities.autoOrganize({
          document_ids,
          strategy: parameters?.strategy || 'smart',
          params: parameters
        })];
        break;

      default:
        return Response.json({
          error: `Unknown operation: ${operation}. Valid operations: delete, move, sign, summarize, organize`
        }, { status: 400 });
    }

    return Response.json({
      success: true,
      operation,
      documents_processed: document_ids.length,
      results
    });

  } catch (error) {
    console.error('Batch operation error:', error);
    return Response.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
}
