# Signal87 Entity Schema Reference

Complete reference for all Base44 entities used in Signal87 AI Platform.

## Overview

Signal87 uses 8 Base44 entities for data storage:

1. **Document** - Document storage with metadata
2. **Folder** - Folder organization
3. **Workspace** - Workspace management
4. **WorkspaceMember** - Team collaboration
5. **ResearchReport** - Research and briefing results
6. **TrainingData** - LLM training data collection
7. **AuditLog** - Action audit trail
8. **AriaFeedback** - User feedback on ARIA

All entities include automatic timestamp fields (`created_at`, `updated_at`) and support soft deletion (`is_deleted`, `deleted_at`).

---

## Document Entity

Stores all documents uploaded to the platform.

### Schema

```json
{
  "id": "uuid (primary key)",
  "title": "string (required, searchable)",
  "file_url": "string (required)",
  "file_type": "string (required)",
  "file_size": "number",
  "file_hash": "string (SHA-256 for deduplication)",
  "workspace_id": "string (required, indexed)",
  "folder_id": "string (indexed)",
  "created_by": "string (required, indexed)",
  "extracted_content": "text (searchable, full document text)",
  "ai_summary": "text (AI-generated summary)",
  "category": "string (indexed)",
  "tags": "array<string>",
  "processing_status": "enum (pending|processing|completed|failed)",
  "processing_error": "text",
  "metadata": "object (additional metadata)",
  "is_deleted": "boolean (default: false, indexed)",
  "deleted_at": "timestamp",
  "created_at": "timestamp (auto)",
  "updated_at": "timestamp (auto)"
}
```

### Indexes

- `workspace_documents` - (workspace_id, created_at)
- `folder_documents` - (folder_id, created_at)
- `user_documents` - (created_by, created_at)
- `document_status` - (processing_status, created_at)

### Example

```json
{
  "id": "doc-abc-123",
  "title": "Q4 Financial Report.pdf",
  "file_url": "https://storage.base44.run/files/abc123.pdf",
  "file_type": "application/pdf",
  "file_size": 2458624,
  "file_hash": "sha256:abc123...",
  "workspace_id": "ws-123",
  "folder_id": "folder-financial",
  "created_by": "user@example.com",
  "extracted_content": "Q4 2024 Financial Report...",
  "ai_summary": "This report shows strong Q4 performance with 18% revenue growth...",
  "category": "financial",
  "tags": ["financial", "q4", "2024"],
  "processing_status": "completed",
  "metadata": {
    "pages": 24,
    "author": "Finance Team",
    "created_date": "2024-01-10"
  },
  "is_deleted": false,
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:35:00Z"
}
```

### Usage

```typescript
// Create document
const doc = await base44.entities.Document.create({
  title: 'Contract.pdf',
  file_url: uploadResult.url,
  file_type: 'application/pdf',
  workspace_id: 'ws-123',
  created_by: user.email
});

// Find documents in folder
const docs = await base44.entities.Document.filter({
  folder_id: 'folder-legal',
  is_deleted: false
});

// Search documents
const results = await base44.entities.Document.search({
  query: 'financial performance',
  limit: 20
});

// Soft delete
await base44.entities.Document.updateById(docId, {
  is_deleted: true,
  deleted_at: new Date().toISOString()
});
```

---

## Folder Entity

Organizes documents into hierarchical folder structures.

### Schema

```json
{
  "id": "uuid (primary key)",
  "name": "string (required, searchable)",
  "description": "text (searchable)",
  "workspace_id": "string (required, indexed)",
  "parent_folder_id": "string (indexed, for nested folders)",
  "created_by": "string (required, indexed)",
  "color": "string (default: gray, UI color)",
  "icon": "string (icon name)",
  "auto_organize_rules": "object (rules for auto-organization)",
  "document_count": "number (default: 0)",
  "is_deleted": "boolean (default: false, indexed)",
  "deleted_at": "timestamp",
  "created_at": "timestamp (auto)",
  "updated_at": "timestamp (auto)"
}
```

### Indexes

- `workspace_folders` - (workspace_id, created_at)
- `parent_folders` - (parent_folder_id, name)

### Example

```json
{
  "id": "folder-legal",
  "name": "Legal Documents",
  "description": "All legal contracts and agreements",
  "workspace_id": "ws-123",
  "parent_folder_id": null,
  "created_by": "admin@example.com",
  "color": "blue",
  "icon": "scale",
  "auto_organize_rules": {
    "keywords": ["contract", "agreement", "NDA"],
    "file_types": [".pdf", ".docx"],
    "auto_apply": true
  },
  "document_count": 42,
  "is_deleted": false,
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-15T10:00:00Z"
}
```

### Usage

```typescript
// Create folder
const folder = await base44.entities.Folder.create({
  name: 'Contracts',
  workspace_id: 'ws-123',
  created_by: user.email,
  color: 'purple'
});

// Create nested folder
const subfolder = await base44.entities.Folder.create({
  name: '2024 Contracts',
  workspace_id: 'ws-123',
  parent_folder_id: folder.id,
  created_by: user.email
});

// Get all root folders
const rootFolders = await base44.entities.Folder.filter({
  workspace_id: 'ws-123',
  parent_folder_id: null,
  is_deleted: false
});
```

---

## Workspace Entity

Manages workspaces for team collaboration and data isolation.

### Schema

```json
{
  "id": "uuid (primary key)",
  "name": "string (required, searchable)",
  "description": "text (searchable)",
  "slug": "string (required, unique, indexed)",
  "owner_email": "string (required, indexed)",
  "plan": "enum (free|pro|enterprise, default: free)",
  "settings": "object (workspace settings)",
  "aria_enabled": "boolean (default: true)",
  "aria_config": "object (ARIA configuration)",
  "storage_used": "number (bytes, default: 0)",
  "storage_limit": "number (bytes)",
  "document_count": "number (default: 0)",
  "member_count": "number (default: 1)",
  "is_deleted": "boolean (default: false, indexed)",
  "deleted_at": "timestamp",
  "created_at": "timestamp (auto)",
  "updated_at": "timestamp (auto)"
}
```

### Indexes

- `owner_workspaces` - (owner_email, created_at)

### Example

```json
{
  "id": "ws-123",
  "name": "ACME Corporation",
  "description": "Main workspace for ACME Corp documents",
  "slug": "acme-corp",
  "owner_email": "admin@acme.com",
  "plan": "enterprise",
  "settings": {
    "allow_external_sharing": false,
    "require_2fa": true,
    "auto_backup": true
  },
  "aria_enabled": true,
  "aria_config": {
    "auto_organize": true,
    "auto_summarize": true,
    "preferred_model": "claude-sonnet-4"
  },
  "storage_used": 10737418240,
  "storage_limit": 1099511627776,
  "document_count": 1523,
  "member_count": 12,
  "is_deleted": false,
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-15T10:00:00Z"
}
```

### Usage

```typescript
// Create workspace
const workspace = await base44.asServiceRole.entities.Workspace.create({
  name: 'My Company',
  slug: 'my-company',
  owner_email: user.email,
  plan: 'pro'
});

// Get user's workspaces
const workspaces = await base44.entities.Workspace.filter({
  owner_email: user.email
});

// Update storage usage
await base44.asServiceRole.entities.Workspace.updateById(wsId, {
  storage_used: newStorageBytes,
  document_count: newDocCount
});
```

---

## WorkspaceMember Entity

Manages team members and their roles within workspaces.

### Schema

```json
{
  "id": "uuid (primary key)",
  "workspace_id": "string (required, indexed)",
  "user_email": "string (required, indexed)",
  "role": "enum (owner|admin|member|viewer, default: member, indexed)",
  "permissions": "array<string> (specific permissions)",
  "invited_by": "string (indexed)",
  "invitation_status": "enum (pending|accepted|declined, default: accepted)",
  "last_active_at": "timestamp",
  "joined_at": "timestamp (auto)",
  "created_at": "timestamp (auto)"
}
```

### Indexes

- `workspace_members` - (workspace_id, role)
- `user_workspaces` - (user_email, workspace_id)

### Unique Constraints

- (workspace_id, user_email) - User can only be member once per workspace

### Example

```json
{
  "id": "member-abc-123",
  "workspace_id": "ws-123",
  "user_email": "john@acme.com",
  "role": "admin",
  "permissions": ["documents.create", "documents.delete", "members.invite"],
  "invited_by": "admin@acme.com",
  "invitation_status": "accepted",
  "last_active_at": "2024-01-15T10:30:00Z",
  "joined_at": "2024-01-10T09:00:00Z",
  "created_at": "2024-01-10T09:00:00Z"
}
```

### Usage

```typescript
// Add member to workspace
const member = await base44.asServiceRole.entities.WorkspaceMember.create({
  workspace_id: 'ws-123',
  user_email: 'new@example.com',
  role: 'member',
  invited_by: currentUser.email
});

// Get workspace members
const members = await base44.entities.WorkspaceMember.filter({
  workspace_id: 'ws-123'
});

// Check if user is admin
const adminMembers = await base44.entities.WorkspaceMember.filter({
  workspace_id: 'ws-123',
  user_email: user.email,
  role: 'admin'
});
const isAdmin = adminMembers.length > 0;
```

---

## ResearchReport Entity

Stores research and briefing results generated by ARIA.

### Schema

```json
{
  "id": "uuid (primary key)",
  "title": "string (required, searchable)",
  "type": "enum (research|briefing, required, indexed)",
  "query": "text (searchable, original query/topic)",
  "content": "text (searchable, full report content)",
  "findings": "array<string> (key findings)",
  "citations": "array<object> (document citations)",
  "document_ids": "array<string> (documents analyzed)",
  "workspace_id": "string (required, indexed)",
  "created_by": "string (required, indexed)",
  "research_depth": "enum (quick|standard|comprehensive|exhaustive)",
  "briefing_type": "enum (analytical|executive|tactical|strategic)",
  "execution_time": "number (milliseconds)",
  "metadata": "object (additional metadata)",
  "is_deleted": "boolean (default: false, indexed)",
  "deleted_at": "timestamp",
  "created_at": "timestamp (auto)",
  "updated_at": "timestamp (auto)"
}
```

### Indexes

- `workspace_reports` - (workspace_id, type, created_at)
- `user_reports` - (created_by, created_at)

### Example

```json
{
  "id": "research-abc-123",
  "title": "Compliance Requirements Research",
  "type": "research",
  "query": "What are all compliance requirements in our policy documents?",
  "content": "Research findings...",
  "findings": [
    "GDPR compliance required for EU customers",
    "Annual SOC 2 audits mandated",
    "Quarterly compliance training required"
  ],
  "citations": [
    {
      "document_id": "doc-123",
      "document_title": "Data Protection Policy",
      "excerpt": "GDPR compliance requires...",
      "page": 3,
      "confidence": 0.95
    }
  ],
  "document_ids": ["doc-123", "doc-456", "doc-789"],
  "workspace_id": "ws-123",
  "created_by": "user@example.com",
  "research_depth": "comprehensive",
  "execution_time": 28450,
  "is_deleted": false,
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Usage

```typescript
// Create research report
const report = await base44.asServiceRole.entities.ResearchReport.create({
  title: 'Compliance Research',
  type: 'research',
  query: 'Find all compliance requirements',
  content: fullReport,
  findings: keyFindings,
  citations: citations,
  document_ids: analyzedDocs,
  workspace_id: 'ws-123',
  created_by: user.email,
  research_depth: 'comprehensive',
  execution_time: executionMs
});

// Get recent reports
const reports = await base44.entities.ResearchReport.filter({
  workspace_id: 'ws-123',
  type: 'briefing'
}).sort({ created_at: -1 }).limit(10);
```

---

## TrainingData Entity

Collects training data from ARIA interactions for LLM fine-tuning.

### Schema

```json
{
  "id": "uuid (primary key)",
  "session_id": "string (required, indexed)",
  "user_email": "string (required, indexed)",
  "input": "text (required, user input)",
  "context": "object (request context)",
  "intent": "object (analyzed intent)",
  "actions_planned": "array<object> (planned actions)",
  "actions_executed": "array<object> (executed actions)",
  "response": "text (required, ARIA response)",
  "success": "boolean (required, indexed)",
  "execution_time": "number (milliseconds)",
  "model_used": "string (indexed, LLM model)",
  "user_feedback": "object (ratings, comments)",
  "error": "text (error message if failed)",
  "metadata": "object (additional metadata)",
  "training_set": "enum (train|validation|test|excluded, default: train, indexed)",
  "created_at": "timestamp (auto, indexed)"
}
```

### Indexes

- `session_training` - (session_id, created_at)
- `user_training` - (user_email, created_at)
- `model_training` - (model_used, success, created_at)
- `training_sets` - (training_set, created_at)

### Example

```json
{
  "id": "training-abc-123",
  "session_id": "session-xyz-789",
  "user_email": "user@example.com",
  "input": "Delete all invoices from 2023",
  "context": {
    "workspace_id": "ws-123",
    "selected_documents": []
  },
  "intent": {
    "primary_action": "delete_documents",
    "entities": {
      "document_type": "invoices",
      "year": "2023"
    },
    "confidence": 0.95
  },
  "actions_planned": [
    {
      "action": "search_documents",
      "parameters": { "type": "invoice", "year": 2023 }
    },
    {
      "action": "delete_documents",
      "parameters": { "document_ids": ["doc-1", "doc-2"] }
    }
  ],
  "actions_executed": [
    {
      "action": "search_documents",
      "success": true,
      "results": 15
    },
    {
      "action": "delete_documents",
      "success": true,
      "documents_deleted": 15
    }
  ],
  "response": "I've deleted 15 invoices from 2023.",
  "success": true,
  "execution_time": 2450,
  "model_used": "claude-sonnet-4-20250514",
  "user_feedback": {
    "rating": 5,
    "helpful": true,
    "timestamp": "2024-01-15T10:35:00Z"
  },
  "training_set": "train",
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Usage

```typescript
// Collect training data (done automatically by ARIA)
await base44.asServiceRole.entities.TrainingData.create({
  session_id: sessionId,
  user_email: user.email,
  input: userMessage,
  intent: analyzedIntent,
  actions_planned: actionPlan,
  actions_executed: executionResults,
  response: ariaResponse,
  success: allActionsSucceeded,
  execution_time: executionMs,
  model_used: 'claude-sonnet-4-20250514',
  training_set: 'train'
});

// Get training data for export
const trainingData = await base44.asServiceRole.entities.TrainingData
  .filter({ training_set: 'train', success: true })
  .limit(10000);

// Export for fine-tuning
const formatted = trainingData.map(item => ({
  messages: [
    { role: 'user', content: item.input },
    { role: 'assistant', content: item.response }
  ],
  metadata: { success: item.success, rating: item.user_feedback?.rating }
}));
```

---

## AuditLog Entity

Tracks all actions for compliance and debugging.

### Schema

```json
{
  "id": "uuid (primary key)",
  "action_type": "string (required, indexed)",
  "entity_type": "string (required, indexed)",
  "entity_id": "string (required, indexed)",
  "workspace_id": "string (required, indexed)",
  "user_email": "string (required, indexed)",
  "session_id": "string (indexed, ARIA session if applicable)",
  "action_details": "object (detailed action information)",
  "before_state": "object (state before action)",
  "after_state": "object (state after action)",
  "ip_address": "string",
  "user_agent": "string",
  "success": "boolean (required, indexed)",
  "error_message": "text",
  "created_at": "timestamp (auto, indexed)"
}
```

### Indexes

- `workspace_audit` - (workspace_id, created_at)
- `user_audit` - (user_email, created_at)
- `entity_audit` - (entity_type, entity_id, created_at)
- `action_audit` - (action_type, created_at)

### Example

```json
{
  "id": "audit-abc-123",
  "action_type": "delete_document",
  "entity_type": "document",
  "entity_id": "doc-123",
  "workspace_id": "ws-123",
  "user_email": "user@example.com",
  "session_id": "session-xyz-789",
  "action_details": {
    "document_title": "Invoice 2023-001.pdf",
    "soft_delete": true,
    "reason": "ARIA request: Delete all 2023 invoices"
  },
  "before_state": {
    "is_deleted": false
  },
  "after_state": {
    "is_deleted": true,
    "deleted_at": "2024-01-15T10:30:00Z"
  },
  "ip_address": "192.168.1.1",
  "user_agent": "Mozilla/5.0...",
  "success": true,
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Usage

```typescript
// Create audit log (done automatically by ARIA)
await base44.asServiceRole.entities.AuditLog.create({
  action_type: 'delete_document',
  entity_type: 'document',
  entity_id: document.id,
  workspace_id: workspace.id,
  user_email: user.email,
  session_id: ariaSessionId,
  action_details: { reason: 'User requested deletion' },
  before_state: { is_deleted: false },
  after_state: { is_deleted: true },
  success: true
});

// Get audit trail for document
const auditTrail = await base44.entities.AuditLog
  .filter({
    entity_type: 'document',
    entity_id: docId
  })
  .sort({ created_at: -1 });

// Get user activity
const userActivity = await base44.entities.AuditLog
  .filter({
    user_email: user.email,
    workspace_id: wsId
  })
  .sort({ created_at: -1 })
  .limit(100);
```

---

## AriaFeedback Entity

Collects user feedback on ARIA responses.

### Schema

```json
{
  "id": "uuid (primary key)",
  "user_id": "string (required, indexed)",
  "user_email": "string (required, indexed)",
  "session_id": "string (required, indexed)",
  "message_id": "string (indexed)",
  "rating": "number (1-5 stars)",
  "helpful": "boolean (indexed, thumbs up/down)",
  "feedback_text": "text (searchable)",
  "feedback_type": "enum (positive|negative|suggestion|bug, indexed)",
  "metadata": "object",
  "timestamp": "timestamp (required, indexed)",
  "created_at": "timestamp (auto)"
}
```

### Indexes

- `session_feedback` - (session_id, timestamp)
- `user_feedback` - (user_email, timestamp)
- `rating_feedback` - (rating, timestamp)

### Example

```json
{
  "id": "feedback-abc-123",
  "user_id": "user-123",
  "user_email": "user@example.com",
  "session_id": "session-xyz-789",
  "message_id": "msg-456",
  "rating": 5,
  "helpful": true,
  "feedback_text": "Very helpful! ARIA understood exactly what I needed.",
  "feedback_type": "positive",
  "metadata": {
    "execution_time": 2450,
    "actions_count": 2
  },
  "timestamp": "2024-01-15T10:35:00Z",
  "created_at": "2024-01-15T10:35:00Z"
}
```

### Usage

```typescript
// Submit feedback (from user)
await base44.entities.AriaFeedback.create({
  user_id: user.id,
  user_email: user.email,
  session_id: sessionId,
  message_id: messageId,
  rating: 5,
  helpful: true,
  feedback_text: 'Great results!',
  feedback_type: 'positive',
  timestamp: new Date().toISOString()
});

// Analyze feedback
const positiveFeedback = await base44.asServiceRole.entities.AriaFeedback
  .filter({ helpful: true })
  .count();

const averageRating = await base44.asServiceRole.entities.AriaFeedback
  .aggregate({ avg: 'rating' });
```

---

## Entity Relationships

```
Workspace
    ├── Documents (many)
    │   └── AuditLogs (many)
    ├── Folders (many)
    │   └── Documents (many)
    ├── Members (many)
    ├── ResearchReports (many)
    └── AuditLogs (many)

User
    ├── Documents (created)
    ├── Folders (created)
    ├── Workspaces (owned)
    ├── WorkspaceMember (memberships)
    ├── TrainingData (interactions)
    ├── AriaFeedback (feedback)
    └── AuditLogs (actions)

Document
    ├── AuditLogs (actions)
    └── Citations in ResearchReports
```

---

## Best Practices

### 1. Always Use Soft Deletes

```typescript
// Don't hard delete
// await base44.entities.Document.deleteById(id);

// Do soft delete
await base44.entities.Document.updateById(id, {
  is_deleted: true,
  deleted_at: new Date().toISOString()
});
```

### 2. Create Audit Logs for Important Actions

```typescript
// Always log important actions
await createAuditLog({
  action_type: 'delete_document',
  entity_type: 'document',
  entity_id: docId,
  // ... other fields
});
```

### 3. Use Service Role for System Operations

```typescript
// For system/admin operations
await base44.asServiceRole.entities.TrainingData.create({ /* ... */ });

// For user operations (enforces permissions)
await base44.entities.Document.create({ /* ... */ });
```

### 4. Include Metadata

```typescript
// Store flexible metadata
await base44.entities.Document.create({
  // ... required fields
  metadata: {
    source: 'upload',
    original_name: file.name,
    processing_version: '1.0.0',
    custom_field: 'value'
  }
});
```

---

## Migration Guide

### Adding New Field

1. Update entity JSON file
2. Deploy updated entity: `base44 entities deploy entities/Document.json --force`
3. Existing records will have `null` or default values for new field

### Removing Field

1. Update entity JSON file (remove field)
2. Deploy: `base44 entities deploy entities/Document.json --force`
3. Data for removed field is preserved but not accessible

### Renaming Field

1. Create new field
2. Migrate data: `base44 entities migrate Document old_field new_field`
3. Remove old field

---

## Support

For entity schema questions:
- **Documentation**: https://docs.signal87.ai/entities
- **Support**: entities@signal87.ai
