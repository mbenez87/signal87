# Signal87 Deployment Guide

Complete guide for deploying Signal87 AI Platform with ARIA to Base44 and Vercel.

## Prerequisites

Before you begin, ensure you have:

1. **Base44 Account** with API access
2. **Vercel Account** for frontend hosting
3. **Node.js 18+** installed locally
4. **Git** installed
5. **Anthropic API Key** (provided by Base44)

## Deployment Overview

The deployment consists of three main steps:

1. **Deploy Backend to Base44** (Deno functions + entities)
2. **Deploy Frontend to Vercel** (React app)
3. **Configure Integration** (API endpoints, authentication)

---

## Part 1: Deploy Backend to Base44

### Step 1: Set Up Base44 Project

1. **Log in to Base44 Dashboard**
   ```
   https://base44.dev
   ```

2. **Create New Project**
   - Project Name: `signal87-ai`
   - Runtime: `Deno`
   - Region: Choose closest to your users

3. **Note Your Project Details**
   ```
   Project ID: [your-project-id]
   API Endpoint: https://[your-project].base44.run
   ```

### Step 2: Install Base44 CLI

```bash
npm install -g @base44/cli

# Login to Base44
base44 login
```

### Step 3: Initialize Base44 Project

```bash
# Navigate to signal87-complete directory
cd signal87-complete

# Initialize Base44
base44 init

# Select your project: signal87-ai
```

### Step 4: Deploy Entity Definitions

Deploy all entity schemas to Base44:

```bash
# Deploy entities
base44 entities deploy entities/Document.json
base44 entities deploy entities/Folder.json
base44 entities deploy entities/Workspace.json
base44 entities deploy entities/WorkspaceMember.json
base44 entities deploy entities/ResearchReport.json
base44 entities deploy entities/TrainingData.json
base44 entities deploy entities/AuditLog.json
base44 entities deploy entities/AriaFeedback.json

# Verify deployment
base44 entities list
```

Expected output:
```
✓ Document
✓ Folder
✓ Workspace
✓ WorkspaceMember
✓ ResearchReport
✓ TrainingData
✓ AuditLog
✓ AriaFeedback
```

### Step 5: Deploy Functions

Deploy all backend functions:

```bash
# Deploy ARIA functions
base44 functions deploy functions/aria-core.js
base44 functions deploy functions/aria-chat.js --route /api/aria/chat
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch
base44 functions deploy functions/aria-research.js --route /api/aria/research
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing
base44 functions deploy functions/aria-upload.js --route /api/aria/upload
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities

# Verify deployment
base44 functions list
```

### Step 6: Configure Environment Variables

Set required environment variables in Base44:

```bash
# Anthropic API key (provided by Base44)
base44 env set ANTHROPIC_API_KEY your-api-key-here

# Base44 configuration (auto-configured)
base44 env set BASE44_PROJECT_ID [your-project-id]
base44 env set BASE44_API_URL https://[your-project].base44.run
```

### Step 7: Test Backend

Test your backend deployment:

```bash
# Test capabilities endpoint
curl https://[your-project].base44.run/api/aria/capabilities

# Expected response: JSON with ARIA capabilities
```

---

## Part 2: Deploy Frontend to Vercel

### Step 1: Prepare Frontend

1. **Update API endpoint** in your code:
   ```typescript
   // In src/hooks/useAria.js and other hooks
   // Replace '/api/aria/chat' with full URL:
   const API_BASE = 'https://[your-project].base44.run';
   ```

2. **Build locally to test**:
   ```bash
   npm install
   npm run build

   # Test build
   npm run preview
   ```

### Step 2: Deploy to Vercel

#### Option A: Using Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Follow prompts:
# - Set up new project? Yes
# - Which scope? [Your team]
# - Link to existing project? No
# - Project name? signal87-ai
# - Directory? ./
# - Override settings? No

# Deploy to production
vercel --prod
```

#### Option B: Using Vercel Dashboard

1. **Push to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial Signal87 deployment"
   git branch -M main
   git remote add origin https://github.com/[your-username]/signal87-ai.git
   git push -u origin main
   ```

2. **Import to Vercel**:
   - Go to https://vercel.com/new
   - Import your GitHub repository
   - Configure project:
     - Framework Preset: `Vite`
     - Root Directory: `./`
     - Build Command: `npm run build`
     - Output Directory: `dist`

3. **Add Environment Variables**:
   ```
   VITE_API_BASE_URL=https://[your-project].base44.run
   ```

4. **Deploy**

### Step 3: Configure Custom Domain (Optional)

1. **In Vercel Dashboard**:
   - Go to your project → Settings → Domains
   - Add domain: `app.signal87.ai`

2. **In DNS Provider (IONOS)**:
   - Add CNAME record:
     ```
     Name: app
     Type: CNAME
     Value: cname.vercel-dns.com
     ```

3. **Verify**:
   - Wait 5-10 minutes for DNS propagation
   - Visit https://app.signal87.ai

---

## Part 3: Configure Integration

### Step 1: Set Up Authentication

Configure Base44 authentication in your Vercel app:

1. **Add auth configuration**:
   ```bash
   # In Vercel environment variables
   VITE_BASE44_PROJECT_ID=[your-project-id]
   ```

2. **Update frontend auth** (if using custom auth):
   ```typescript
   // In src/App.tsx
   import { Base44Auth } from '@base44/sdk';

   const auth = new Base44Auth({
     projectId: import.meta.env.VITE_BASE44_PROJECT_ID
   });
   ```

### Step 2: Configure CORS

Allow your Vercel domain to access Base44 API:

```bash
# In Base44 dashboard or CLI
base44 cors add https://signal87-ai.vercel.app
base44 cors add https://app.signal87.ai
```

### Step 3: Test Integration

1. **Visit your deployed app**:
   ```
   https://signal87-ai.vercel.app
   ```

2. **Test ARIA chat**:
   - Click ARIA button (bottom-right)
   - Send test message: "What can you do?"
   - Verify response

3. **Test document operations**:
   - Upload a document
   - Try batch operations
   - Verify in Base44 dashboard

### Step 4: Monitor Deployment

Set up monitoring:

1. **Vercel Analytics**:
   - Enable in Vercel dashboard
   - Monitor performance

2. **Base44 Logs**:
   ```bash
   # View function logs
   base44 logs --function aria-chat --follow

   # View error logs
   base44 logs --level error
   ```

3. **Sentry (Optional)**:
   ```bash
   npm install @sentry/react

   # Configure in src/main.tsx
   ```

---

## Troubleshooting

### Backend Issues

**Problem**: Functions not deploying
```bash
# Check Base44 status
base44 status

# View deployment logs
base44 logs --deployment [deployment-id]

# Redeploy specific function
base44 functions deploy functions/aria-chat.js --force
```

**Problem**: Entity creation fails
```bash
# Validate entity schema
base44 entities validate entities/Document.json

# Check for naming conflicts
base44 entities list
```

### Frontend Issues

**Problem**: Build fails on Vercel
```bash
# Build locally to debug
npm run build

# Check Node version (should be 18+)
node --version

# Clear cache and rebuild
rm -rf node_modules dist
npm install
npm run build
```

**Problem**: API requests fail
```typescript
// Check CORS configuration
// Verify API_BASE_URL in environment variables
// Check browser console for errors
```

### Integration Issues

**Problem**: Authentication fails
```bash
# Verify Base44 credentials
base44 whoami

# Check environment variables
base44 env list
```

**Problem**: ARIA not responding
```bash
# Check function logs
base44 logs --function aria-chat --tail 50

# Test endpoint directly
curl -X POST https://[your-project].base44.run/api/aria/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello ARIA"}'
```

---

## Production Checklist

Before going live:

- [ ] All entities deployed and verified
- [ ] All functions deployed and tested
- [ ] Environment variables configured
- [ ] CORS configured for production domain
- [ ] Custom domain configured (if applicable)
- [ ] SSL certificates active
- [ ] Authentication working
- [ ] ARIA chat functional
- [ ] Document upload working
- [ ] Batch operations tested
- [ ] Research/briefing generation tested
- [ ] Error monitoring set up
- [ ] Performance monitoring enabled
- [ ] Backup strategy in place

---

## Maintenance

### Updating Backend

```bash
# Pull latest changes
git pull origin main

# Deploy updated functions
base44 functions deploy functions/aria-core.js

# Redeploy dependent functions
base44 functions deploy functions/aria-chat.js
```

### Updating Frontend

```bash
# Vercel auto-deploys on git push
git push origin main

# Or deploy manually
vercel --prod
```

### Database Migrations

```bash
# Create backup
base44 entities export Document > backup-document.json

# Update entity
base44 entities deploy entities/Document.json --force

# Verify
base44 entities describe Document
```

---

## Support

For deployment issues:
- **Base44 Support**: support@base44.dev
- **Vercel Support**: https://vercel.com/support
- **Signal87 Team**: dev@signal87.ai

---

## Next Steps

After deployment:
1. Review [API.md](API.md) for API reference
2. Review [ENTITIES.md](ENTITIES.md) for database schema
3. Invite team members to workspace
4. Set up monitoring dashboards
5. Configure backup strategies
6. Plan for scaling (if needed)

**Congratulations!** Your Signal87 AI Platform with ARIA is now live! 🎉
