# Signal87 ARIA API Reference

Complete API reference for Signal87 AI Platform with ARIA agent system.

## Base URL

```
https://[your-project].base44.run/api/aria
```

## Authentication

All API endpoints require authentication using Base44's authentication system:

```bash
# Include authentication header
Authorization: Bearer [your-access-token]
```

For frontend applications using Base44 SDK, authentication is handled automatically.

---

## Endpoints

### 1. Chat - Main Conversational Interface

**Endpoint**: `POST /api/aria/chat`

Main endpoint for natural language interactions with ARIA.

#### Request

```json
{
  "message": "Delete all invoices from 2023",
  "context": {
    "workspace_id": "workspace-123",
    "active_folder_id": "folder-456"
  },
  "session_id": "session-abc-123"
}
```

**Parameters:**
- `message` (string, required): User's natural language request
- `context` (object, optional): Additional context for ARIA
  - `workspace_id` (string): Current workspace
  - `active_folder_id` (string): Currently selected folder
  - `selected_documents` (array): Currently selected documents
- `session_id` (string, optional): Session ID for conversation continuity

#### Response

```json
{
  "success": true,
  "message": "I've deleted 15 invoices from 2023. They have been moved to trash and can be recovered within 30 days.",
  "actions_performed": 1,
  "session_id": "session-abc-123",
  "execution_time": 2450,
  "results": [
    {
      "action": "delete_documents",
      "success": true,
      "documents_affected": 15,
      "details": {
        "moved_to_trash": true,
        "recovery_deadline": "2024-02-15T10:30:00Z"
      }
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `400` - Invalid request (missing message)
- `401` - Unauthorized
- `500` - Server error

#### Example Usage

```typescript
// Using fetch
const response = await fetch('/api/aria/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: 'Generate a briefing on Q4 financial documents',
    context: { workspace_id: 'ws-123' }
  })
});

const data = await response.json();
console.log(data.message); // ARIA's response
console.log(data.results); // Actions performed
```

---

### 2. Batch Document Operations

**Endpoint**: `POST /api/aria/documents/batch`

Perform batch operations on multiple documents.

#### Request

```json
{
  "operation": "sign",
  "document_ids": ["doc-1", "doc-2", "doc-3"],
  "parameters": {
    "signature_type": "digital"
  }
}
```

**Parameters:**
- `operation` (string, required): Operation type
  - `delete` - Delete documents
  - `move` - Move to folder
  - `sign` - Apply signature
  - `summarize` - Generate summaries
  - `organize` - Auto-organize
- `document_ids` (array, required): Document IDs to process
- `parameters` (object, optional): Operation-specific parameters

**Operation-Specific Parameters:**

**For `move`**:
```json
{
  "target_folder_id": "folder-123"
}
```

**For `sign`**:
```json
{
  "signature_type": "digital" | "electronic" | "wet"
}
```

**For `summarize`**:
```json
{
  "summary_type": "executive" | "technical" | "comprehensive" | "bullet_points",
  "max_length": 5000
}
```

**For `organize`**:
```json
{
  "strategy": "smart" | "by_type" | "by_date" | "by_category"
}
```

#### Response

```json
{
  "success": true,
  "operation": "sign",
  "documents_processed": 3,
  "results": [
    {
      "document_id": "doc-1",
      "success": true,
      "signature_applied": true,
      "signature_id": "sig-abc-123"
    },
    {
      "document_id": "doc-2",
      "success": true,
      "signature_applied": true,
      "signature_id": "sig-def-456"
    },
    {
      "document_id": "doc-3",
      "success": false,
      "error": "Document locked by another user"
    }
  ]
}
```

#### Example Usage

```typescript
// Delete documents
await fetch('/api/aria/documents/batch', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    operation: 'delete',
    document_ids: ['doc-1', 'doc-2']
  })
});

// Move documents
await fetch('/api/aria/documents/batch', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    operation: 'move',
    document_ids: ['doc-1', 'doc-2'],
    parameters: { target_folder_id: 'folder-legal' }
  })
});
```

---

### 3. Deep Research

**Endpoint**: `POST /api/aria/research`

Conduct comprehensive research across multiple documents.

#### Request

```json
{
  "query": "What are all the compliance requirements mentioned in our policy documents?",
  "document_ids": ["doc-1", "doc-2", "doc-3"],
  "depth": "comprehensive",
  "include_web_search": false
}
```

**Parameters:**
- `query` (string, required): Research question
- `document_ids` (array, optional): Specific documents to research (empty = all)
- `depth` (string, optional): Research depth
  - `quick` - Fast overview (5-10s)
  - `standard` - Balanced (10-20s)
  - `comprehensive` - Thorough (20-40s)
  - `exhaustive` - Complete (40-60s+)
- `include_web_search` (boolean, optional): Include web search results

#### Response

```json
{
  "success": true,
  "research_id": "research-abc-123",
  "query": "What are all the compliance requirements mentioned in our policy documents?",
  "documents_analyzed": 47,
  "findings": [
    "GDPR compliance required for all EU customer data",
    "Annual security audits mandated by SOC 2",
    "Quarterly compliance training for all employees",
    "Data retention policies must comply with state regulations"
  ],
  "citations": [
    {
      "document_id": "doc-policy-001",
      "document_title": "Data Protection Policy 2024",
      "excerpt": "All customer data from EU residents must be processed in accordance with GDPR...",
      "page": 3,
      "confidence": 0.95
    },
    {
      "document_id": "doc-policy-015",
      "document_title": "Security Compliance Framework",
      "excerpt": "Annual SOC 2 Type II audits are required to maintain certification...",
      "page": 12,
      "confidence": 0.92
    }
  ],
  "execution_time": 28450
}
```

#### Example Usage

```typescript
const research = await fetch('/api/aria/research', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    query: 'Find all mentions of ACME Corp',
    depth: 'comprehensive'
  })
});

const data = await research.json();
console.log('Findings:', data.findings);
console.log('Citations:', data.citations);
```

---

### 4. Briefing Generation

**Endpoint**: `POST /api/aria/briefing`

Generate comprehensive analytical briefings.

#### Request

```json
{
  "topic": "Q4 2024 Financial Performance",
  "document_ids": ["doc-1", "doc-2", "doc-3"],
  "briefing_type": "analytical"
}
```

**Parameters:**
- `topic` (string, required): Briefing topic
- `document_ids` (array, optional): Documents to analyze
- `briefing_type` (string, optional): Type of briefing
  - `analytical` - Detailed analysis with data
  - `executive` - High-level summary
  - `tactical` - Action-oriented
  - `strategic` - Long-term planning

#### Response

```json
{
  "success": true,
  "briefing_id": "briefing-abc-123",
  "topic": "Q4 2024 Financial Performance",
  "briefing_type": "analytical",
  "documents_used": 12,
  "content": "# Q4 2024 Financial Performance Analysis\n\n## Executive Summary\n\nQ4 2024 demonstrated strong growth...\n\n## Key Metrics\n\n- Revenue: $12.4M (+18% YoY)\n- Operating Margin: 32% (+5 pp YoY)\n- Customer Acquisition: 2,400 (+25% YoY)\n\n## Detailed Analysis\n\n### Revenue Growth\n\nThe 18% year-over-year revenue growth was driven primarily by...\n\n### Cost Management\n\nOperating expenses remained well-controlled...\n\n## Conclusions\n\n1. Strong revenue growth momentum continues\n2. Operational efficiency improvements paying off\n3. Customer acquisition trending positively\n\n## Recommendations\n\n1. Continue investment in high-performing channels\n2. Optimize customer onboarding process\n3. Expand into adjacent markets in Q1 2025",
  "document_id": "doc-briefing-abc-123",
  "execution_time": 35200
}
```

The generated briefing is also saved as a new document and a ResearchReport entity.

#### Example Usage

```typescript
const briefing = await fetch('/api/aria/briefing', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    topic: 'Patent Portfolio Analysis',
    briefing_type: 'strategic',
    document_ids: ['patent-1', 'patent-2', 'patent-3']
  })
});

const data = await briefing.json();
console.log('Briefing:', data.content);
```

---

### 5. Document Upload with Auto-Processing

**Endpoint**: `POST /api/aria/upload`

Upload documents with automatic AI processing.

#### Request (multipart/form-data)

```
POST /api/aria/upload
Content-Type: multipart/form-data

file: [binary file data]
workspace_id: workspace-123
auto_process: true
```

**Parameters:**
- `file` (file, required): Document file
- `workspace_id` (string, optional): Target workspace
- `auto_process` (boolean, optional): Enable AI processing

#### Response

```json
{
  "success": true,
  "document_id": "doc-new-123",
  "title": "Q4 Financial Report.pdf",
  "file_url": "https://storage.base44.run/files/abc123.pdf",
  "auto_processed": true,
  "summary": "This financial report covers Q4 2024 performance...",
  "category": "financial",
  "suggested_folder": "Financial Reports",
  "tags": ["financial", "q4", "2024", "report"]
}
```

If `auto_process: false`:

```json
{
  "success": true,
  "document_id": "doc-new-123",
  "title": "Contract.pdf",
  "file_url": "https://storage.base44.run/files/xyz789.pdf",
  "auto_processed": false
}
```

#### Example Usage

```typescript
// Upload with auto-processing
const formData = new FormData();
formData.append('file', fileInput.files[0]);
formData.append('auto_process', 'true');
formData.append('workspace_id', 'ws-123');

const response = await fetch('/api/aria/upload', {
  method: 'POST',
  body: formData
});

const data = await response.json();
console.log('Summary:', data.summary);
console.log('Suggested folder:', data.suggested_folder);
```

---

### 6. User Feedback

**Endpoint**: `POST /api/aria/feedback`

Submit feedback on ARIA responses for training data improvement.

#### Request

```json
{
  "session_id": "session-abc-123",
  "message_id": "msg-456",
  "rating": 5,
  "feedback_text": "Very helpful and accurate!",
  "helpful": true
}
```

**Parameters:**
- `session_id` (string, required): ARIA session ID
- `message_id` (string, optional): Specific message ID
- `rating` (number, optional): 1-5 star rating
- `feedback_text` (string, optional): Free-form feedback
- `helpful` (boolean, optional): Simple thumbs up/down

#### Response

```json
{
  "success": true,
  "message": "Feedback recorded",
  "feedback_id": "feedback-abc-123"
}
```

#### Example Usage

```typescript
// Thumbs up
await fetch('/api/aria/feedback', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    session_id: sessionId,
    message_id: messageId,
    helpful: true
  })
});

// Detailed feedback
await fetch('/api/aria/feedback', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    session_id: sessionId,
    rating: 4,
    feedback_text: 'Good results but could be faster'
  })
});
```

---

### 7. Get Capabilities

**Endpoint**: `GET /api/aria/capabilities`

Get list of ARIA's capabilities (useful for UI display).

#### Request

```
GET /api/aria/capabilities
```

No parameters required.

#### Response

```json
{
  "version": "1.0.0",
  "platform": "Signal87 AI",
  "document_operations": [
    {
      "id": "delete",
      "name": "Delete Documents",
      "description": "Permanently delete or move documents to trash",
      "parameters": ["document_ids"],
      "examples": [
        "Delete all invoices from 2023",
        "Remove the old contracts"
      ]
    }
    // ... more operations
  ],
  "research_operations": [
    {
      "id": "research",
      "name": "Deep Research",
      "description": "Comprehensive analysis across multiple documents",
      "parameters": ["query", "document_ids", "depth"],
      "depth_levels": ["quick", "standard", "comprehensive", "exhaustive"],
      "examples": [
        "Research all mentions of ACME Corp across documents"
      ]
    }
    // ... more operations
  ],
  "natural_language": {
    "enabled": true,
    "description": "Ask ARIA to do anything in plain English",
    "examples": [
      "Delete all invoices from 2023",
      "Generate a comprehensive briefing on Q4"
    ]
  },
  "llm_models": [
    {
      "id": "claude-sonnet-4-20250514",
      "name": "Claude Sonnet 4",
      "use_cases": ["complex reasoning", "deep analysis"],
      "context_window": 200000
    }
  ],
  "features": {
    "autonomous_actions": true,
    "multi_step_planning": true,
    "semantic_search": true,
    "training_data_collection": true
  }
}
```

#### Example Usage

```typescript
const capabilities = await fetch('/api/aria/capabilities');
const data = await capabilities.json();

// Display in UI
console.log('ARIA can:', data.natural_language.examples);
```

---

## Error Handling

All endpoints return errors in the following format:

```json
{
  "success": false,
  "error": "Error message here"
}
```

### Common Error Codes

- `400` - Bad Request (invalid parameters)
- `401` - Unauthorized (authentication required)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found (resource doesn't exist)
- `429` - Rate Limit Exceeded
- `500` - Internal Server Error

### Example Error Handling

```typescript
try {
  const response = await fetch('/api/aria/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: 'Hello' })
  });

  const data = await response.json();

  if (!data.success) {
    throw new Error(data.error);
  }

  // Handle success
} catch (error) {
  console.error('ARIA error:', error.message);
  // Display error to user
}
```

---

## Rate Limits

API rate limits per endpoint:

- **Chat**: 60 requests/minute
- **Research/Briefing**: 10 requests/minute (computationally expensive)
- **Batch Operations**: 30 requests/minute
- **Upload**: 20 uploads/minute
- **Feedback**: 100 requests/minute
- **Capabilities**: Unlimited (cached)

Rate limit headers are included in responses:

```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 58
X-RateLimit-Reset: 1640000000
```

---

## Webhooks (Future)

Webhook support for long-running operations:

```json
{
  "webhook_url": "https://your-app.com/webhooks/aria",
  "events": ["research_complete", "briefing_complete"]
}
```

---

## SDKs

### JavaScript/TypeScript

```bash
npm install @signal87/aria-sdk
```

```typescript
import { AriaClient } from '@signal87/aria-sdk';

const aria = new AriaClient({
  apiKey: 'your-api-key',
  baseUrl: 'https://[your-project].base44.run'
});

// Chat
const response = await aria.chat('Delete all invoices from 2023');

// Research
const research = await aria.research('Find compliance requirements');

// Briefing
const briefing = await aria.briefing('Q4 Performance', {
  type: 'analytical'
});
```

---

## Support

For API support:
- **Documentation**: https://docs.signal87.ai
- **Support**: api@signal87.ai
- **Status**: https://status.signal87.ai
