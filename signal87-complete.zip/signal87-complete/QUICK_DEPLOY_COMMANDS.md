# 🚀 Quick Deploy Commands - Copy & Paste

**Deploy Signal87 as a brand new app in 15 minutes.**

---

## Step 1: Install & Setup (2 minutes)

```bash
# Install CLI tools
npm install -g @base44/cli
npm install -g vercel

# Login to Base44
base44 login

# Navigate to project
cd /home/user/signal87-complete
```

---

## Step 2: Create New Base44 Project (3 minutes)

```bash
# Initialize new project
base44 init
# Choose: "Create new project"
# Name: signal87-platform
# Runtime: Deno
# Region: us-east-1
```

---

## Step 3: Deploy Backend (5 minutes)

**Copy & paste this entire block:**

```bash
# Deploy all entities
base44 entities deploy entities/Document.json && \
base44 entities deploy entities/Folder.json && \
base44 entities deploy entities/Workspace.json && \
base44 entities deploy entities/WorkspaceMember.json && \
base44 entities deploy entities/ResearchReport.json && \
base44 entities deploy entities/TrainingData.json && \
base44 entities deploy entities/AuditLog.json && \
base44 entities deploy entities/AriaFeedback.json && \
echo "✅ Entities deployed"
```

**Then copy & paste this block:**

```bash
# Deploy all functions
base44 functions deploy functions/aria-core.js && \
base44 functions deploy functions/aria-chat.js --route /api/aria/chat && \
base44 functions deploy functions/aria-documents.js --route /api/aria/documents/batch && \
base44 functions deploy functions/aria-research.js --route /api/aria/research && \
base44 functions deploy functions/aria-briefing.js --route /api/aria/briefing && \
base44 functions deploy functions/aria-upload.js --route /api/aria/upload && \
base44 functions deploy functions/aria-feedback.js --route /api/aria/feedback && \
base44 functions deploy functions/aria-capabilities.js --route /api/aria/capabilities && \
echo "✅ Functions deployed"
```

**Get your API endpoint:**

```bash
base44 info
# Note the URL: https://[your-project-id].base44.run
```

**Test it:**

```bash
curl https://[your-project-id].base44.run/api/aria/capabilities
```

---

## Step 4: Push to GitHub (3 minutes)

**Create new GitHub repository:**
1. Go to: https://github.com/new
2. Name: `signal87-platform`
3. Make it Private
4. Click "Create repository"

**Push code:**

```bash
# Initialize git
git init
git add .
git commit -m "Initial commit: Signal87 AI Platform"

# Push (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/signal87-platform.git
git branch -M main
git push -u origin main
```

---

## Step 5: Deploy to Vercel (5 minutes)

**Option A: Vercel Dashboard** (Recommended)

1. Go to: https://vercel.com/new
2. Import your `signal87-platform` repository
3. Configure:
   - Framework: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Add Environment Variable:
   - Name: `VITE_API_BASE_URL`
   - Value: `https://[your-project-id].base44.run`
5. Click "Deploy"

**Option B: Vercel CLI**

```bash
# Deploy
vercel

# Add environment variable
vercel env add VITE_API_BASE_URL production
# Enter: https://[your-project-id].base44.run

# Deploy to production
vercel --prod
```

---

## Step 6: Configure CORS (1 minute)

```bash
# Add your Vercel domain
base44 cors add https://signal87-platform.vercel.app

# Add localhost for testing
base44 cors add http://localhost:3000
```

---

## Step 7: Test Your App (2 minutes)

1. Visit: `https://signal87-platform.vercel.app`
2. Click "Get Started"
3. Click ARIA button (bottom-right)
4. Type: "What can you do?"
5. ARIA should respond!

---

## ✅ Done!

**Your new app is live:**
- Frontend: `https://signal87-platform.vercel.app`
- Backend: `https://[your-project-id].base44.run`

---

## Optional: Add Custom Domain

**In Vercel:**
1. Project Settings → Domains
2. Add: `platform.signal87.ai` or `aria.signal87.ai`

**In IONOS DNS:**
```
Type: CNAME
Name: platform (or aria)
Value: cname.vercel-dns.com
```

**Update CORS:**
```bash
base44 cors add https://platform.signal87.ai
```

---

## Commands Reference

### View logs
```bash
base44 logs --function aria-chat --tail 50
```

### Redeploy function
```bash
base44 functions deploy functions/aria-chat.js --force
```

### Update frontend
```bash
git add .
git commit -m "Update"
git push
# Vercel auto-deploys
```

---

## Troubleshooting

**Backend not working?**
```bash
base44 logs --function aria-chat --level error
```

**CORS error?**
```bash
base44 cors add https://your-domain.vercel.app
```

**Frontend not building?**
```bash
npm install
npm run build
```

---

## Need detailed instructions?

See `DEPLOY_NEW_APP.md` for complete step-by-step guide.

---

**That's it! You're done! 🎉**
