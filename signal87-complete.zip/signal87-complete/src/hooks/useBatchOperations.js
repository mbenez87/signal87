/**
 * useBatchOperations Hook
 * Hook for batch document operations (delete, move, sign, summarize, organize)
 */

import { useState, useCallback } from 'react';

export function useBatchOperations() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState({ current: 0, total: 0 });

  const executeBatchOperation = useCallback(async (operation, documentIds, parameters = {}) => {
    if (!operation || !documentIds?.length) {
      throw new Error('Operation and document IDs required');
    }

    setIsLoading(true);
    setError(null);
    setProgress({ current: 0, total: documentIds.length });

    try {
      const response = await fetch('/api/aria/documents/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          operation,
          document_ids: documentIds,
          parameters
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Operation failed');
      }

      setProgress({ current: documentIds.length, total: documentIds.length });

      return data;

    } catch (err) {
      console.error('Batch operation error:', err);
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const deleteDocuments = useCallback(async (documentIds) => {
    return executeBatchOperation('delete', documentIds);
  }, [executeBatchOperation]);

  const moveDocuments = useCallback(async (documentIds, targetFolderId) => {
    return executeBatchOperation('move', documentIds, { target_folder_id: targetFolderId });
  }, [executeBatchOperation]);

  const signDocuments = useCallback(async (documentIds, signatureType = 'digital') => {
    return executeBatchOperation('sign', documentIds, { signature_type: signatureType });
  }, [executeBatchOperation]);

  const summarizeDocuments = useCallback(async (documentIds, summaryType = 'executive', maxLength = 5000) => {
    return executeBatchOperation('summarize', documentIds, {
      summary_type: summaryType,
      max_length: maxLength
    });
  }, [executeBatchOperation]);

  const organizeDocuments = useCallback(async (documentIds, strategy = 'smart') => {
    return executeBatchOperation('organize', documentIds, { strategy });
  }, [executeBatchOperation]);

  return {
    isLoading,
    error,
    progress,
    deleteDocuments,
    moveDocuments,
    signDocuments,
    summarizeDocuments,
    organizeDocuments,
    executeBatchOperation
  };
}
