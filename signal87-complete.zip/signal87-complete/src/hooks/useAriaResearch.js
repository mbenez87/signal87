/**
 * useAriaResearch Hook
 * Hook for conducting deep research across documents
 */

import { useState, useCallback } from 'react';

export function useAriaResearch() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentResearch, setCurrentResearch] = useState(null);

  const conductResearch = useCallback(async (query, documentIds = [], depth = 'comprehensive', includeWebSearch = false) => {
    if (!query?.trim()) {
      throw new Error('Query required');
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/aria/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          document_ids: documentIds,
          depth,
          include_web_search: includeWebSearch
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Research failed');
      }

      setCurrentResearch(data);

      return data;

    } catch (err) {
      console.error('Research error:', err);
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const generateBriefing = useCallback(async (topic, documentIds = [], briefingType = 'analytical') => {
    if (!topic?.trim()) {
      throw new Error('Topic required');
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/aria/briefing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          document_ids: documentIds,
          briefing_type: briefingType
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Briefing generation failed');
      }

      setCurrentResearch(data);

      return data;

    } catch (err) {
      console.error('Briefing error:', err);
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearResearch = useCallback(() => {
    setCurrentResearch(null);
    setError(null);
  }, []);

  return {
    isLoading,
    error,
    currentResearch,
    conductResearch,
    generateBriefing,
    clearResearch
  };
}
