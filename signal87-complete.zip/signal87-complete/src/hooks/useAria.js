/**
 * useAria Hook
 * Main hook for interacting with ARIA chat
 */

import { useState, useCallback, useRef } from 'react';

export function useAria() {
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId, setSessionId] = useState(() => `session-${Date.now()}`);
  const [error, setError] = useState(null);

  const abortControllerRef = useRef(null);

  const sendMessage = useCallback(async (message, context = {}) => {
    if (!message?.trim()) return;

    setIsLoading(true);
    setError(null);

    // Add user message
    const userMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: message,
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, userMessage]);

    try {
      abortControllerRef.current = new AbortController();

      const response = await fetch('/api/aria/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          context,
          session_id: sessionId
        }),
        signal: abortControllerRef.current.signal
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Request failed');
      }

      // Add ARIA response
      const ariaMessage = {
        id: `msg-${Date.now()}-aria`,
        role: 'assistant',
        content: data.message,
        results: data.results,
        actions_performed: data.actions_performed,
        execution_time: data.execution_time,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, ariaMessage]);

      return data;

    } catch (err) {
      if (err.name === 'AbortError') {
        console.log('Request aborted');
        return;
      }

      console.error('ARIA error:', err);
      setError(err.message);

      // Add error message
      const errorMessage = {
        id: `msg-${Date.now()}-error`,
        role: 'error',
        content: `Error: ${err.message}`,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);

      throw err;
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  }, [sessionId]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setSessionId(`session-${Date.now()}`);
    setError(null);
  }, []);

  const cancelRequest = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  const submitFeedback = useCallback(async (messageId, rating, feedbackText, helpful) => {
    try {
      const response = await fetch('/api/aria/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionId,
          message_id: messageId,
          rating,
          feedback_text: feedbackText,
          helpful
        })
      });

      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }

      return await response.json();
    } catch (err) {
      console.error('Feedback error:', err);
      throw err;
    }
  }, [sessionId]);

  return {
    messages,
    isLoading,
    error,
    sessionId,
    sendMessage,
    clearMessages,
    cancelRequest,
    submitFeedback
  };
}
