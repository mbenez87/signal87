/**
 * GenerationDashboard Component
 * Grok-style AI generation interface for reports, briefings, and analysis
 */

import React, { useState } from 'react';
import { Sparkles, FileText, Search, TrendingUp, Loader2, Download, Copy } from 'lucide-react';
import { useAriaResearch } from '../hooks/useAriaResearch';

export function GenerationDashboard() {
  const [prompt, setPrompt] = useState('');
  const [generationType, setGenerationType] = useState('briefing');
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [generatedContent, setGeneratedContent] = useState(null);

  const { isLoading, error, generateBriefing, conductResearch } = useAriaResearch();

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    try {
      if (generationType === 'briefing') {
        const result = await generateBriefing(prompt, selectedDocuments, 'analytical');
        setGeneratedContent(result);
      } else if (generationType === 'research') {
        const result = await conductResearch(prompt, selectedDocuments, 'comprehensive');
        setGeneratedContent(result);
      }
    } catch (err) {
      console.error('Generation error:', err);
    }
  };

  const copyToClipboard = () => {
    if (generatedContent?.content) {
      navigator.clipboard.writeText(generatedContent.content);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-lg">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Generation Dashboard</h1>
          <p className="text-zinc-400 text-sm">AI-powered reports, briefings, and deep research</p>
        </div>
      </div>

      {/* Generation Type Selector */}
      <div className="flex gap-3">
        <button
          onClick={() => setGenerationType('briefing')}
          className={`flex-1 p-4 rounded-lg border transition-all ${
            generationType === 'briefing'
              ? 'bg-blue-600 border-blue-500 text-white'
              : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
          }`}
        >
          <FileText className="w-5 h-5 mx-auto mb-2" />
          <p className="font-medium text-sm">Briefing</p>
          <p className="text-xs opacity-80 mt-1">Structured analytical report</p>
        </button>

        <button
          onClick={() => setGenerationType('research')}
          className={`flex-1 p-4 rounded-lg border transition-all ${
            generationType === 'research'
              ? 'bg-purple-600 border-purple-500 text-white'
              : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
          }`}
        >
          <Search className="w-5 h-5 mx-auto mb-2" />
          <p className="font-medium text-sm">Deep Research</p>
          <p className="text-xs opacity-80 mt-1">Comprehensive analysis</p>
        </button>

        <button
          onClick={() => setGenerationType('trend')}
          className={`flex-1 p-4 rounded-lg border transition-all ${
            generationType === 'trend'
              ? 'bg-green-600 border-green-500 text-white'
              : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
          }`}
        >
          <TrendingUp className="w-5 h-5 mx-auto mb-2" />
          <p className="font-medium text-sm">Trend Analysis</p>
          <p className="text-xs opacity-80 mt-1">Pattern detection</p>
        </button>
      </div>

      {/* Input Area */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium text-zinc-300 mb-2">
            What would you like to generate?
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              generationType === 'briefing'
                ? 'e.g., "Generate an executive briefing on Q4 financial performance"'
                : generationType === 'research'
                ? 'e.g., "Research all mentions of ACME Corp across documents"'
                : 'e.g., "Analyze trends in customer feedback over the last quarter"'
            }
            rows={6}
            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-4 text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </div>

        <div className="flex items-center justify-between">
          <p className="text-sm text-zinc-500">
            {selectedDocuments.length} documents selected
          </p>
          <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-zinc-700 disabled:to-zinc-700 disabled:text-zinc-500 text-white px-6 py-2 rounded-lg font-medium transition-all flex items-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Generate
              </>
            )}
          </button>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-900/50 border border-red-800 rounded-lg p-4">
          <p className="text-red-200 text-sm">{error}</p>
        </div>
      )}

      {/* Generated Content */}
      {generatedContent && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white">
              {generationType === 'briefing' ? 'Briefing' : 'Research'} Results
            </h3>
            <div className="flex gap-2">
              <button
                onClick={copyToClipboard}
                className="text-zinc-400 hover:text-white p-2 rounded hover:bg-zinc-800 transition-colors"
                title="Copy to clipboard"
              >
                <Copy className="w-4 h-4" />
              </button>
              <button
                className="text-zinc-400 hover:text-white p-2 rounded hover:bg-zinc-800 transition-colors"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          {generationType === 'briefing' && (
            <div className="space-y-3">
              <div>
                <p className="text-sm text-zinc-400">Topic</p>
                <p className="text-white">{generatedContent.topic}</p>
              </div>
              <div>
                <p className="text-sm text-zinc-400">Type</p>
                <p className="text-white capitalize">{generatedContent.briefing_type}</p>
              </div>
              <div>
                <p className="text-sm text-zinc-400">Documents Used</p>
                <p className="text-white">{generatedContent.documents_used}</p>
              </div>
              <div className="pt-3 border-t border-zinc-800">
                <p className="text-sm text-zinc-400 mb-2">Content</p>
                <div className="bg-zinc-800 rounded-lg p-4">
                  <div className="text-zinc-100 text-sm whitespace-pre-wrap prose prose-invert max-w-none">
                    {generatedContent.content}
                  </div>
                </div>
              </div>
            </div>
          )}

          {generationType === 'research' && (
            <div className="space-y-3">
              <div>
                <p className="text-sm text-zinc-400">Query</p>
                <p className="text-white">{generatedContent.query}</p>
              </div>
              <div>
                <p className="text-sm text-zinc-400">Documents Analyzed</p>
                <p className="text-white">{generatedContent.documents_analyzed}</p>
              </div>
              {generatedContent.findings && generatedContent.findings.length > 0 && (
                <div>
                  <p className="text-sm text-zinc-400 mb-2">Key Findings</p>
                  <ul className="space-y-2">
                    {generatedContent.findings.map((finding, idx) => (
                      <li key={idx} className="bg-zinc-800 rounded-lg p-3 text-sm text-zinc-100">
                        {finding}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {generatedContent.citations && generatedContent.citations.length > 0 && (
                <div>
                  <p className="text-sm text-zinc-400 mb-2">Citations</p>
                  <div className="space-y-2">
                    {generatedContent.citations.map((citation, idx) => (
                      <div key={idx} className="bg-zinc-800 rounded-lg p-3 text-xs">
                        <p className="text-white font-medium">{citation.document_title}</p>
                        <p className="text-zinc-400 mt-1">{citation.excerpt}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="pt-3 border-t border-zinc-800 flex justify-between text-xs text-zinc-500">
            <span>Generated {new Date().toLocaleString()}</span>
            {generatedContent.execution_time && (
              <span>{(generatedContent.execution_time / 1000).toFixed(2)}s</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
