/**
 * Dashboard Component
 * Main dashboard with dark theme, document management, and ARIA integration
 */

import React, { useState } from 'react';
import {
  FileText,
  Folder,
  Sparkles,
  Settings,
  LogOut,
  Search,
  Upload,
  MoreVertical,
  Trash2,
  FolderInput,
  FileSignature,
  FileCheck
} from 'lucide-react';
import { AriaChat } from '../components/AriaChat';
import { GenerationDashboard } from '../components/GenerationDashboard';
import { useBatchOperations } from '../hooks/useBatchOperations';

export function Dashboard() {
  const [activeTab, setActiveTab] = useState('generate');
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  const { deleteDocuments, moveDocuments, signDocuments, summarizeDocuments } = useBatchOperations();

  // Mock documents - replace with real data from API
  const mockDocuments = [
    {
      id: '1',
      title: 'Q4 Financial Report.pdf',
      thumbnail: 'https://placehold.co/300x400/1a1a1a/ffffff?text=Q4+Report',
      type: 'pdf',
      size: '2.4 MB',
      date: '2024-01-15'
    },
    {
      id: '2',
      title: 'ACME Contract.pdf',
      thumbnail: 'https://placehold.co/300x400/1a1a1a/ffffff?text=Contract',
      type: 'pdf',
      size: '1.8 MB',
      date: '2024-01-14'
    },
    {
      id: '3',
      title: 'Board Meeting Notes.docx',
      thumbnail: 'https://placehold.co/300x400/1a1a1a/ffffff?text=Notes',
      type: 'docx',
      size: '156 KB',
      date: '2024-01-13'
    }
  ];

  const mockFolders = [
    { id: '1', name: 'Legal', count: 24, color: 'blue' },
    { id: '2', name: 'Financial', count: 18, color: 'green' },
    { id: '3', name: 'Contracts', count: 32, color: 'purple' },
    { id: '4', name: 'Reports', count: 15, color: 'orange' }
  ];

  const toggleDocumentSelection = (docId) => {
    setSelectedDocuments(prev =>
      prev.includes(docId) ? prev.filter(id => id !== docId) : [...prev, docId]
    );
  };

  const handleBatchAction = async (action) => {
    if (selectedDocuments.length === 0) return;

    try {
      switch (action) {
        case 'delete':
          await deleteDocuments(selectedDocuments);
          break;
        case 'sign':
          await signDocuments(selectedDocuments, 'digital');
          break;
        case 'summarize':
          await summarizeDocuments(selectedDocuments);
          break;
      }
      setSelectedDocuments([]);
    } catch (err) {
      console.error('Batch action error:', err);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Sidebar */}
      <div className="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">Signal87</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => setActiveTab('generate')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activeTab === 'generate'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span className="font-medium">Generate</span>
          </button>

          <button
            onClick={() => setActiveTab('documents')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activeTab === 'documents'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="font-medium">Documents</span>
          </button>

          <button
            onClick={() => setActiveTab('folders')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activeTab === 'folders'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <Folder className="w-5 h-5" />
            <span className="font-medium">Folders</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activeTab === 'settings'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="font-medium">Settings</span>
          </button>
        </nav>

        {/* User */}
        <div className="p-4 border-t border-zinc-800">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800/50 transition-colors">
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-8">
          {/* Generation Dashboard */}
          {activeTab === 'generate' && <GenerationDashboard />}

          {/* Documents View */}
          {activeTab === 'documents' && (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-white">Documents</h1>
                  <p className="text-zinc-400 text-sm">Manage your documents</p>
                </div>
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  Upload
                </button>
              </div>

              {/* Search & Filters */}
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search documents..."
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-10 pr-4 py-3 text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Batch Actions */}
              {selectedDocuments.length > 0 && (
                <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex items-center justify-between">
                  <span className="text-sm text-zinc-400">
                    {selectedDocuments.length} document{selectedDocuments.length !== 1 && 's'} selected
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleBatchAction('sign')}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-sm flex items-center gap-2 transition-colors"
                    >
                      <FileSignature className="w-4 h-4" />
                      Sign
                    </button>
                    <button
                      onClick={() => handleBatchAction('summarize')}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-sm flex items-center gap-2 transition-colors"
                    >
                      <FileCheck className="w-4 h-4" />
                      Summarize
                    </button>
                    <button
                      onClick={() => handleBatchAction('delete')}
                      className="px-3 py-1.5 bg-red-900/50 hover:bg-red-900 rounded text-sm flex items-center gap-2 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  </div>
                </div>
              )}

              {/* Document Grid - Dropbox Style */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {mockDocuments.map(doc => (
                  <div
                    key={doc.id}
                    className={`bg-zinc-900 rounded-lg border cursor-pointer transition-all hover:border-zinc-600 ${
                      selectedDocuments.includes(doc.id)
                        ? 'border-blue-500 ring-2 ring-blue-500/50'
                        : 'border-zinc-800'
                    }`}
                    onClick={() => toggleDocumentSelection(doc.id)}
                  >
                    {/* Thumbnail */}
                    <div className="aspect-[3/4] bg-zinc-800 relative overflow-hidden rounded-t-lg">
                      <img
                        src={doc.thumbnail}
                        alt={doc.title}
                        className="w-full h-full object-cover"
                      />
                      {selectedDocuments.includes(doc.id) && (
                        <div className="absolute top-2 right-2 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                          <FileCheck className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="p-3">
                      <p className="text-sm font-medium text-white truncate">{doc.title}</p>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-zinc-500">{doc.size}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          className="text-zinc-500 hover:text-white"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Folders View */}
          {activeTab === 'folders' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white">Folders</h1>
                <p className="text-zinc-400 text-sm">Organize your documents</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {mockFolders.map(folder => (
                  <div
                    key={folder.id}
                    className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 hover:border-zinc-700 cursor-pointer transition-all"
                  >
                    <Folder className={`w-12 h-12 text-${folder.color}-500 mb-3`} />
                    <p className="font-medium text-white">{folder.name}</p>
                    <p className="text-sm text-zinc-500 mt-1">{folder.count} documents</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Settings View */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white">Settings</h1>
                <p className="text-zinc-400 text-sm">Manage your workspace</p>
              </div>

              <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-white mb-4">ARIA Configuration</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Enable ARIA</p>
                      <p className="text-sm text-zinc-500">Allow ARIA to assist with document operations</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Auto-organize</p>
                      <p className="text-sm text-zinc-500">Let ARIA automatically organize documents</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ARIA Chat - Omnipresent */}
      <AriaChat context={{ activeTab, selectedDocuments }} />
    </div>
  );
}
