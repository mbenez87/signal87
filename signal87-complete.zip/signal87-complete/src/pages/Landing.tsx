/**
 * Landing Page Component
 * Dark theme landing page matching Signal87 design
 */

import React from 'react';
import { Sparkles, FileText, Search, TrendingUp, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-8 py-20">
        <div className="text-center space-y-8">
          {/* Logo */}
          <div className="flex items-center justify-center gap-3">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-lg">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <span className="text-3xl font-bold">Signal87</span>
          </div>

          {/* Headline */}
          <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            AI-Powered Document Intelligence
          </h1>

          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Meet ARIA - your autonomous AI assistant that understands, organizes, and analyzes your documents with unprecedented intelligence
          </p>

          {/* CTA */}
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all flex items-center gap-2"
            >
              Get Started
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all">
              Learn More
            </button>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-32">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
            <div className="bg-blue-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <FileText className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Smart Organization</h3>
            <p className="text-zinc-400">
              ARIA automatically categorizes and organizes your documents, creating intelligent folder structures
            </p>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Search className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Deep Research</h3>
            <p className="text-zinc-400">
              Conduct comprehensive research across thousands of documents with AI-powered analysis and citations
            </p>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
            <div className="bg-green-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Intelligent Briefings</h3>
            <p className="text-zinc-400">
              Generate executive briefings, analytical reports, and trend analyses in seconds
            </p>
          </div>
        </div>

        {/* ARIA Capabilities */}
        <div className="mt-32 text-center">
          <h2 className="text-4xl font-bold mb-6">What ARIA Can Do</h2>
          <p className="text-xl text-zinc-400 mb-12 max-w-2xl mx-auto">
            Your AI assistant that truly understands your documents
          </p>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8 text-left max-w-3xl mx-auto">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-600/20 w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium">Natural Language Commands</p>
                  <p className="text-zinc-400 text-sm">
                    "Delete all invoices from 2023" or "Generate a briefing on Q4 performance"
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-600/20 w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium">Batch Operations</p>
                  <p className="text-zinc-400 text-sm">
                    Process hundreds of documents simultaneously - sign, move, summarize, organize
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-600/20 w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium">Deep Document Analysis</p>
                  <p className="text-zinc-400 text-sm">
                    Comprehensive research with citations, key findings, and actionable insights
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-600/20 w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium">Continuous Learning</p>
                  <p className="text-zinc-400 text-sm">
                    ARIA learns from every interaction to provide better results over time
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-32 text-center text-zinc-600 text-sm">
          <p>© 2024 Signal87. Powered by Claude AI.</p>
        </div>
      </div>
    </div>
  );
}
